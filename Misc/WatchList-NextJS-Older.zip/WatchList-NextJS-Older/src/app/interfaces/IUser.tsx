export default interface User {
     UserID: number,
     Username: string,
     Realname: string,
     Password: string,
     Admin: boolean,
     Enabled: boolean
}