export default interface IWatchListItemsSortColumn {
     key: string,
     value: string
}