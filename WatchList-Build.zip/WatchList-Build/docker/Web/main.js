(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["main"],{

/***/ 158:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 2816);



const routes = [
    {
        path: '',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_tabs_tabs_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./tabs/tabs.module */ 5564)).then(m => m.TabsPageModule)
    },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.NgModule)({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule.forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__.PreloadAllModules, useHash: true })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule]
    })
], AppRoutingModule);



/***/ }),

/***/ 5041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _app_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.component.html?ngResource */ 3383);
/* harmony import */ var _app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component.scss?ngResource */ 9259);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _core_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./core/data.service */ 3943);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);








let AppComponent = class AppComponent {
    constructor(dataService, location, menu, router) {
        this.dataService = dataService;
        this.menu = menu;
        this.router = router;
        this.currentRoute = '';
        this.isEditingOptions = false;
        this.itemsPerPage = [
            10,
            20,
            50,
            100,
            500,
            1000
        ];
        this.recordLimitOptions = [
            10,
            50,
            100,
            500,
            1000
        ];
        // save current route so I can show filters in the menu that depend on the active tab
        router.events.subscribe(() => {
            if (location.path() !== '') {
                switch (location.path()) {
                    case '/tabs/watchlist':
                        this.currentRoute = 'WatchList';
                        break;
                    case '/tabs/watchlist-items':
                        this.currentRoute = 'WatchListItems';
                        break;
                }
            }
        });
    }
    editOptions() {
        this.isEditingOptions = true;
    }
    optionChangeHandler(event) {
        this.dataService.saveIncompleteFilter();
        this.dataService.saveRecordLimitFilter();
        this.dataService.saveSourceFilter();
        this.dataService.saveTypeFilter();
        this.dataService.saveItemsPerPageFilter();
        this.dataService.saveIMDBURLMissingFilter();
    }
    signOut() {
        this.dataService.confirmDialog(null, 'Are you sure that you want to sign out ?', this.signOutConfirmClickHandler.bind(this));
    }
    signOutConfirmClickHandler() {
        //this.dataService.setBackendURL();
        this.dataService.isLoggedIn = false;
        this.dataService.runRest('/SignOut', 'GET', null).subscribe((response) => {
            this.menu.close();
            this.router.navigateByUrl('/');
            // TODO: There is a bug where after logging out, the login form is ready only
            window.location.reload();
        }, error => {
            this.router.navigateByUrl('/tabs/login');
        });
        /*setTimeout(() => {
             this.router.navigateByUrl('/tabs/login');
        }, 10000)*/
    }
    // Used to prevent the entire DOM tree from being re-rendered every time that there is a change
    trackByFn(index, item) {
        return index; // or item.id
    }
};
AppComponent.ctorParameters = () => [
    { type: _core_data_service__WEBPACK_IMPORTED_MODULE_2__.DataService },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_3__.Location },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.MenuController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router }
];
AppComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-root',
        template: _app_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AppComponent);



/***/ }),

/***/ 6747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/platform-browser */ 318);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app-routing.module */ 158);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component */ 5041);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/cdk/overlay */ 4244);
/* harmony import */ var _components_detail_overlay_detail_overlay__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/detail-overlay/detail-overlay */ 6183);
/* harmony import */ var _components_watchlist_detail_watchlist_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/watchlist-detail/watchlist-detail-page */ 5027);
/* harmony import */ var _components_watchlist_items_detail_watchlist_items_detail_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/watchlist-items-detail/watchlist-items-detail-page */ 7897);
/* harmony import */ var _components_watchlist_queue_detail_watchlist_queue_detail_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/watchlist-queue-detail/watchlist-queue-detail-page */ 6417);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/storage-angular */ 7566);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common/http */ 8784);















let AppModule = class AppModule {
};
AppModule = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.NgModule)({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_1__.AppComponent, _components_watchlist_detail_watchlist_detail_page__WEBPACK_IMPORTED_MODULE_3__.WatchListDetailComponent, _components_watchlist_items_detail_watchlist_items_detail_page__WEBPACK_IMPORTED_MODULE_4__.WatchListItemsDetailComponent, _components_watchlist_queue_detail_watchlist_queue_detail_page__WEBPACK_IMPORTED_MODULE_5__.WatchListQueueDetailComponent, _components_detail_overlay_detail_overlay__WEBPACK_IMPORTED_MODULE_2__.DetailOverlayComponent],
        imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__.BrowserModule, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormsModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_10__.HttpClientModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonicModule.forRoot(), _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_12__.IonicStorageModule.forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_0__.AppRoutingModule, _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_13__.OverlayModule],
        providers: [{ provide: _angular_router__WEBPACK_IMPORTED_MODULE_14__.RouteReuseStrategy, useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonicRouteStrategy }],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_1__.AppComponent],
    })
], AppModule);



/***/ }),

/***/ 6183:
/*!*************************************************************!*\
  !*** ./src/app/components/detail-overlay/detail-overlay.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetailOverlayComponent": () => (/* binding */ DetailOverlayComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _detail_overlay_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./detail-overlay.page.html?ngResource */ 2508);
/* harmony import */ var _detail_overlay_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./detail-overlay.page.scss?ngResource */ 3964);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _core_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../core/data.service */ 3943);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);






let DetailOverlayComponent = class DetailOverlayComponent {
    constructor(dataService, router, route) {
        this.dataService = dataService;
        this.router = router;
        this.route = route;
    }
    ngDoCheck() {
        this.detailObjectName = this.route.snapshot.paramMap.get('ObjectName');
        this.dataService.authGuardDisabled = false;
        if (this.detailObjectName == null) {
            this.router.navigateByUrl('/');
        }
    }
};
DetailOverlayComponent.ctorParameters = () => [
    { type: _core_data_service__WEBPACK_IMPORTED_MODULE_2__.DataService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.ActivatedRoute }
];
DetailOverlayComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-detailoverlay',
        template: _detail_overlay_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_detail_overlay_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], DetailOverlayComponent);



/***/ }),

/***/ 5027:
/*!**********************************************************************!*\
  !*** ./src/app/components/watchlist-detail/watchlist-detail-page.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WatchListDetailComponent": () => (/* binding */ WatchListDetailComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _watchlist_detail_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlist-detail.page.html?ngResource */ 2971);
/* harmony import */ var _watchlist_detail_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./watchlist-detail.page.scss?ngResource */ 6632);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _core_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../core/data.service */ 3943);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6362);






let WatchListDetailComponent = class WatchListDetailComponent {
    constructor(dataService) {
        this.dataService = dataService;
        this.addItemID = 0;
        this.addItemStartDate = '';
        this.addItemEndDate = '';
        this.addItemNotes = '';
        this.addItemSource = '';
        this.addSeason = '';
        this.addRating = 0;
        this.lastIndex = null;
        this.lastRating = null;
        this.math = Math;
        this.wasModified = false;
    }
    ngDoCheck() {
        this.detailObject = this.dataService.getDetailObject();
        this.detailObjectName = this.dataService.getDetailObjectName();
        const addWatchListItemID = this.dataService.getDetailWatchListItemID();
        if (this.dataService.getDetailID() == null) {
            this.isAdding = true;
            // Default start date to current date
            //const dateStr = new Date().setSeconds(0,0);
            //const dt = new Date(dateStr).toISOString().substring(0,10);
            //if (this.addItemStartDate === '') {
            //     this.addItemStartDate=dt;
            //}
        }
        else
            this.isAdding = false;
        if (addWatchListItemID !== null) {
            this.addItemID = addWatchListItemID;
            this.isAdding = true;
            this.detailObject = this.dataService.iWatchListEmpty();
        }
    }
    // Add Queue item to WatchList Queue and remove from WatchList
    addToWatchListQueue() {
        const currWatchListItem = [];
        currWatchListItem.WatchListItemID = this.detailObject['WatchListItemID'];
        const d = new Date();
        const pipe = new _angular_common__WEBPACK_IMPORTED_MODULE_3__.DatePipe('en-US');
        const now = Date.now();
        const formattedDate = pipe.transform(now, 'shortDate');
        currWatchListItem.StartDate = formattedDate;
        currWatchListItem.WatchListID = this.detailObject['WatchListID']; // Needed so we can delete the watchlist item later
        if (this.detailObject['Notes'] !== null && this.detailObject['Notes'] !== '') {
            currWatchListItem.Notes = this.detailObject['Notes'];
        }
        else {
            currWatchListItem.Notes = 'Added from WatchList';
        }
        this.dataService.confirmDialog(currWatchListItem, 'Are you sure that you want to move this item to the WatchList Queue?', this.addToWatchListQueueCallback.bind(this));
    }
    addToWatchListQueueCallback() {
        this.dataService.addWatchListQueueItem(this.detailObject).subscribe((response) => {
            this.deleteWatchListCallback();
            this.dataService.getWatchListSubscription(); // Reload WatchList after moving item from WatchList to WatchListQueue
            this.dataService.getWatchListQueueSubscription();
            this.dataService.closeOverlay();
            this.dataService.alert('Added to Watch List Queue');
        }, error => {
            this.dataService.alert(`Error ${error} occurred. Not addded to Watch List QueueQQQ`);
            this.dataService.handleError(error);
        });
    }
    cancelWatchList() {
        if (this.isEditing) {
            this.detailObject.WatchListItemID = this.detailObject[`Previous`].WatchListItemID;
            this.detailObject.StartDate = this.detailObject[`Previous`].StartDate;
            this.detailObject.EndDate = this.detailObject[`Previous`].EndDate;
            this.detailObject.WatchListSourceID = this.detailObject[`Previous`].WatchListSourceID;
            this.detailObject.Rating = this.detailObject[`Previous`].Rating;
            this.detailObject.Notes = this.detailObject[`Previous`].Notes;
            this.isEditing = false;
        }
        if (this.isAdding) {
            this.isEditing = false;
            this.addItemID = 0;
            this.dataService.closeOverlay();
        }
    }
    closeClickHandler() {
        if (this.wasModified)
            this.dataService.getWatchListSubscription();
        this.dataService.closeOverlay();
    }
    deleteWatchList(currWatchList) {
        this.dataService.confirmDialog(currWatchList, 'Are you sure that you want to delete this item ?', this.deleteWatchListCallback.bind(this));
    }
    deleteWatchListCallback() {
        this.dataService.deleteWatchList(this.detailObject['WatchListID']).subscribe((response) => {
            this.dataService.closeOverlay();
            this.dataService.getWatchListSubscription(); // Reload WatchList after deleting a WatchList record
        }, error => {
            console.log(`An error occurred deleting WatchList Item with ID ${this.detailObject['WatchListID']}`);
        });
    }
    editWatchList() {
        this.isEditing = true;
        this.detailObject[`Previous`] = [];
        Object.assign(this.detailObject[`Previous`], this.detailObject);
    }
    getRatingIcon(index) {
        var _a, _b;
        if (this.isAdding)
            return this.addRating > index + 0.5 ? "heart" : this.addRating === index + 0.5 ? "heart-half" : "heart-outline";
        else
            return ((_a = this.detailObject) === null || _a === void 0 ? void 0 : _a.Rating) > index + 0.5 ? "heart" : ((_b = this.detailObject) === null || _b === void 0 ? void 0 : _b.Rating) === index + 0.5 ? "heart-half" : "heart-outline";
    }
    numSequence(n) {
        return Array(n);
    }
    ratingClickHandler(index) {
        if (!this.isAdding && !this.isEditing)
            return true;
        if (this.isAdding) {
            if (String(this.addRating + ".0") === String(index + ".0")) {
                this.addRating = index + 0.5;
            }
            else if (String(this.addRating) === String(index + ".5")) {
                this.addRating = parseFloat((index + 1).toFixed(1));
            }
            else {
                this.addRating = parseFloat(index.toFixed(1));
            }
            return;
        }
        else {
            if (this.detailObject.Rating === null)
                this.detailObject.Rating = 0;
            if (String(this.detailObject.Rating + ".0") === String(index + ".0")) {
                this.detailObject.Rating = index + 0.5;
            }
            else if (String(this.detailObject.Rating) === String(index + ".5")) {
                this.detailObject.Rating = parseFloat((index + 1).toFixed(1));
            }
            else {
                this.detailObject.Rating = parseFloat(index.toFixed(1));
            }
        }
    }
    saveWatchList() {
        if (this.isAdding) {
            this.saveNewWatchList();
        }
        if (this.isEditing) {
            this.saveExistingWatchList();
        }
    }
    saveNewWatchList() {
        if (this.addItemID === 0) {
            this.dataService.alert(`Please select the name`);
            return;
        }
        if (this.addItemStartDate === ``) {
            this.dataService.alert(`Please enter the start date`);
            return;
        }
        const currWatchList = [];
        currWatchList.WatchListItemID = this.addItemID;
        currWatchList.StartDate = this.addItemStartDate;
        currWatchList.EndDate = this.addItemEndDate;
        currWatchList.Notes = this.addItemNotes;
        currWatchList.WatchListSourceID = this.addItemSource;
        currWatchList.Season = this.addSeason;
        // Clear fields to prevent user from saving twice
        this.addItemID = 0;
        this.addItemStartDate = '';
        this.addItemEndDate = '';
        this.addItemNotes = '';
        this.addItemSource = '';
        this.addSeason = '';
        this.addRating = 0;
        this.dataService.addWatchList(currWatchList).subscribe((response) => {
            this.isAdding = false;
            this.dataService.detailID = null;
            this.wasModified = true;
            this.dataService.getWatchListSubscription(); // Reload WatchList after adding a WatchList record
            this.dataService.closeOverlay();
        }, error => {
            // Restore fields values in case the user made a mistake & wants to resubmit
            this.addItemID = currWatchList.WatchListItemID;
            this.addItemStartDate = currWatchList.StartDate;
            this.addItemEndDate = currWatchList.EndDate;
            this.addItemNotes = currWatchList.Notes;
            this.addItemSource = currWatchList.WatchListSourceID;
            this.addSeason = currWatchList.Season;
            this.dataService.handleError(error);
        });
    }
    saveExistingWatchList() {
        if (String(this.detailObject[`WatchListID`]) === ``) {
            this.dataService.alert(`Please select the name`);
            return;
        }
        if (String(this.detailObject[`StartDate`]) === ``) {
            this.dataService.alert(`Please enter the start date`);
            return;
        }
        if (isNaN(this.detailObject[`Season`])) {
            this.dataService.alert(`Please enter a number for the season`);
            return;
        }
        this.dataService.updateWatchList(this.detailObject).subscribe((response) => {
            if (response !== null && response.length > 0 && response[0] === "ERROR") {
                alert(response[1]);
                return;
            }
            this.detailObject[`Disabled`] = true;
            this.isEditing = false;
            this.wasModified = true;
            this.dataService.getWatchListSubscription(); // Reload WatchList after updating a WatchList record
        }, error => {
            this.dataService.handleError(error);
        });
    }
};
WatchListDetailComponent.ctorParameters = () => [
    { type: _core_data_service__WEBPACK_IMPORTED_MODULE_2__.DataService }
];
WatchListDetailComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-watchlist-detail',
        template: _watchlist_detail_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_watchlist_detail_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], WatchListDetailComponent);



/***/ }),

/***/ 7897:
/*!**********************************************************************************!*\
  !*** ./src/app/components/watchlist-items-detail/watchlist-items-detail-page.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WatchListItemsDetailComponent": () => (/* binding */ WatchListItemsDetailComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _watchlist_items_detail_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlist-items-detail.page.html?ngResource */ 3038);
/* harmony import */ var _watchlist_items_detail_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./watchlist-items-detail.page.scss?ngResource */ 1988);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _core_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../core/data.service */ 3943);





let WatchListItemsDetailComponent = class WatchListItemsDetailComponent {
    constructor(dataService) {
        this.dataService = dataService;
        this.addItemName = '';
        this.addItemType = '';
        this.addItemIMDBPoster = '';
        this.addItemIMDBURL = '';
        this.addItemNotes = '';
    }
    ngDoCheck() {
        this.detailObject = this.dataService.getDetailObject();
        this.detailObjectName = this.dataService.getDetailObjectName();
        if (this.dataService.getDetailID() == null) {
            this.isAdding = true;
        }
    }
    cancelWatchListItem() {
        if (this.isEditing) {
            this.detailObject.WatchListItemName = this.detailObject.Previous.WatchListItemName;
            this.detailObject.WatchListTypeID = this.detailObject.Previous.WatchListTypeID;
            this.detailObject.IMDB_URL = this.detailObject.Previous.IMDB_URL;
            this.detailObject.ItemNotes = this.detailObject.Previous.ItemNotes;
            this.isEditing = false;
        }
        if (this.isAdding) {
            this.isEditing = false;
            this.dataService.closeOverlay();
        }
    }
    deleteWatchListItem(currWatchListItem) {
        this.dataService.confirmDialog(currWatchListItem, 'Are you sure that you want to delete this item ?', this.deleteWatchListItemCallback.bind(this));
    }
    deleteWatchListItemCallback(currWatchListItem) {
        this.dataService.deleteWatchListItem(currWatchListItem.WatchListItemID).subscribe((response) => {
            this.dataService.getWatchListItemsSubscription(true); // Reload WatchListItems after deleting a WatchList record
        }, error => {
            console.log(`An error occurred deleting WatchList Item with ID ${currWatchListItem.WatchListID}`);
        });
    }
    editWatchListItem() {
        this.isEditing = true;
        this.detailObject.Previous = this.dataService.iWatchListItemEmpty();
        Object.assign(this.detailObject.Previous, this.detailObject);
    }
    saveWatchListItem() {
        if (this.isAdding) {
            this.saveNewWatchListItem();
        }
        if (this.isEditing) {
            this.saveExistingWatchListItem();
        }
    }
    saveNewWatchListItem() {
        if (this.addItemName === ``) {
            this.dataService.alert(`Please select the name`);
            return;
        }
        if (this.addItemType === ``) {
            this.dataService.alert(`Please enter the start date`);
            return;
        }
        const currWatchList = [];
        currWatchList.Name = this.addItemName;
        currWatchList.Type = this.addItemType;
        currWatchList.IMDB_URL = this.addItemIMDBURL;
        currWatchList.IMDB_Poster = this.addItemIMDBPoster;
        currWatchList.ItemNotes = this.addItemNotes;
        this.dataService.addWatchListItem(currWatchList).subscribe((response) => {
            this.dataService.getWatchListItemsSubscription(true); // Reload WatchListItems after adding a WatchList record
            this.isAdding = false;
            this.dataService.closeOverlay();
            this.dataService.autoAddWatchListRecord(this.addItemIMDBURL);
            this.addItemName = '';
            this.addItemType = '';
            this.addItemIMDBURL = '';
            this.addItemIMDBPoster = '';
            this.addItemNotes = '';
        }, error => {
            this.dataService.handleError(error);
        });
    }
    saveExistingWatchListItem() {
        if (this.detailObject.WatchListItemName === ``) {
            this.dataService.alert(`Please select the name`);
            return;
        }
        if (this.detailObject.WatchListTypeID === null) {
            this.dataService.alert(`Please select the type`);
            return;
        }
        this.dataService.updateWatchListItem(this.detailObject).subscribe((response) => {
            this.isEditing = false;
            this.dataService.getWatchListItemsSubscription(true); // Reload WatchListItems after updating a WatchList record
        }, error => {
            this.dataService.handleError(error);
        });
    }
};
WatchListItemsDetailComponent.ctorParameters = () => [
    { type: _core_data_service__WEBPACK_IMPORTED_MODULE_2__.DataService }
];
WatchListItemsDetailComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-watchlist-items-detail',
        template: _watchlist_items_detail_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_watchlist_items_detail_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], WatchListItemsDetailComponent);



/***/ }),

/***/ 6417:
/*!**********************************************************************************!*\
  !*** ./src/app/components/watchlist-queue-detail/watchlist-queue-detail-page.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WatchListQueueDetailComponent": () => (/* binding */ WatchListQueueDetailComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _watchlist_queue_detail_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlist-queue-detail.page.html?ngResource */ 2764);
/* harmony import */ var _watchlist_queue_detail_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./watchlist-queue-detail.page.scss?ngResource */ 4552);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _core_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../core/data.service */ 3943);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 6362);






let WatchListQueueDetailComponent = class WatchListQueueDetailComponent {
    constructor(dataService) {
        this.dataService = dataService;
        this.addQueueItemID = '';
        this.addQueueItemNotes = '';
    }
    ngDoCheck() {
        this.detailObject = this.dataService.getDetailObject();
        this.detailObjectName = this.dataService.getDetailObjectName();
        if (this.dataService.getDetailID() == null) {
            this.isAdding = true;
        }
    }
    // Add Queue item to WatchList and remove from WatchList Queue
    addToWatchList() {
        const currWatchListItem = [];
        currWatchListItem.WatchListItemID = this.detailObject.WatchListItemID;
        const d = new Date();
        const pipe = new _angular_common__WEBPACK_IMPORTED_MODULE_3__.DatePipe('en-US');
        const now = Date.now();
        const formattedDate = pipe.transform(now, 'shortDate');
        currWatchListItem.StartDate = formattedDate;
        // Needed so we can delete the queue item later
        currWatchListItem.WatchListQueueItemID = this.detailObject.WatchListQueueItemID;
        if (this.detailObject.Notes !== null && this.detailObject.Notes !== '') {
            currWatchListItem.Notes = this.detailObject.Notes;
        }
        else {
            currWatchListItem.Notes = 'Added from queue';
        }
        this.dataService.confirmDialog(currWatchListItem, 'Are you sure that you want to move this item to the WatchList ?', this.addToWatchListCallback.bind(this));
    }
    addToWatchListCallback() {
        const newWatchList = {
            WatchListID: null,
            WatchListItemID: this.detailObject.WatchListItemID,
            UserID: this.detailObject.UserID,
            StartDate: new Date(),
            EndDate: null,
            WatchListSourceID: null,
            Season: null,
            Rating: null,
            IMDB_Poster: null,
            Notes: ''
        };
        this.dataService.addWatchList(newWatchList).subscribe((response) => {
            this.deleteWatchListQueueItemCallback();
            this.dataService.getWatchListSubscription(); // Reload WatchList after moving a WatchList record from the queue to WatchList
        }, error => {
            this.dataService.handleError(error);
        });
    }
    cancelWatchListQueueItem() {
        if (this.isEditing) {
            this.detailObject.WatchListItemID = this.detailObject.Previous.WatchListItemID;
            this.detailObject.Notes = this.detailObject.Previous.Notes;
            this.isEditing = false;
        }
        else if (this.isAdding) {
            this.addQueueItemID = '';
            this.addQueueItemNotes = '';
            this.isAdding = false;
            this.dataService.closeOverlay();
        }
    }
    deleteWatchListQueueItem() {
        this.dataService.confirmDialog(this.detailObject, 'Are you sure that you want to delete this queue item ?', this.deleteWatchListQueueItemCallback.bind(this));
    }
    deleteWatchListQueueItemCallback() {
        this.dataService.deleteWatchListQueueItem(this.detailObject.WatchListQueueItemID).subscribe((response) => {
            this.dataService.getWatchListQueueSubscription();
        }, error => {
            console.log(`An error occurred deleting WatchList Queue Item with ID ${this.detailObject.WatchListQueueItemID}`);
        });
    }
    editWatchListQueueItem() {
        this.isEditing = true;
        this.detailObject.Previous = this.dataService.iWatchListQueueItemEmpty();
        Object.assign(this.detailObject.Previous, this.detailObject);
    }
    saveWatchListQueueItem() {
        if (this.isAdding) {
            this.saveNewWatchListQueueItem();
        }
        if (this.isEditing) {
            this.saveExistingWatchListQueueItem();
        }
    }
    saveNewWatchListQueueItem() {
        if (this.addQueueItemID === ``) {
            this.dataService.alert(`Please select the name`);
            return;
        }
        const currWatchListQueueItem = [];
        currWatchListQueueItem.WatchListItemID = this.addQueueItemID;
        currWatchListQueueItem.Notes = this.addQueueItemNotes;
        this.dataService.addWatchListQueueItem(currWatchListQueueItem).subscribe((response) => {
            this.addQueueItemID = '';
            this.addQueueItemNotes = '';
            this.isAdding = false;
            this.dataService.getWatchListQueueSubscription();
        }, error => {
            this.dataService.handleError(error);
        });
    }
    saveExistingWatchListQueueItem() {
        if (this.detailObject.WatchListItemID === null) {
            this.dataService.alert(`Please select the name`);
            return;
        }
        this.dataService.updateWatchListQueueItem(this.detailObject).subscribe((response) => {
            this.isEditing = false;
            this.dataService.getWatchListQueueSubscription();
        }, error => {
            this.dataService.handleError(error);
        });
    }
};
WatchListQueueDetailComponent.ctorParameters = () => [
    { type: _core_data_service__WEBPACK_IMPORTED_MODULE_2__.DataService }
];
WatchListQueueDetailComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-watchlist-queue-detail',
        template: _watchlist_queue_detail_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_watchlist_queue_detail_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], WatchListQueueDetailComponent);



/***/ }),

/***/ 3943:
/*!**************************************!*\
  !*** ./src/app/core/data.service.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DataService": () => (/* binding */ DataService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 8784);
/* harmony import */ var rxjs___WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/ */ 6587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ionic/storage */ 190);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 2816);








let DataService = class DataService {
    constructor(alertController, http, storage, toastController, router) {
        this.alertController = alertController;
        this.http = http;
        this.storage = storage;
        this.toastController = toastController;
        this.router = router;
        this.authGuardDisabled = false;
        this.detailObjectName = null;
        this.detailID = null;
        this.detailWatchListItemID = null;
        this.IMDBSearchEnabled = false;
        this.imdb_url_missing = false;
        this.incompleteFilter = true;
        this.isError = false;
        this.isIMDBSearchEnabled = false;
        this.isLoggedIn = false;
        this.isLoggedInCheckComplete = false;
        this.itemsPerPage = 20;
        this.ratingMax = 5;
        this.recordLimit = 10;
        this.searchTerm = '';
        this.sourceFilter = '';
        this.typeFilter = '';
        this.userData = this.iUserEmpty();
        this.watchListSortActiveColumn = 'Name';
        this.watchListSortColumn = 'Name';
        this.watchListSortDirection = 'ASC';
        this.watchListItemsSortActiveColumn = 'Name';
        this.watchListItemsSortColumn = 'Name';
        this.watchListItemsSortDirection = 'ASC';
        this.watchListColumnSizes = {
            ID: 1,
            Name: 2,
            StartDate: 2,
            EndDate: 2,
            Source: 2,
            Season: 1,
            Rating: 1,
            //Notes : 1,
        };
        this.watchListItemsColumnSizes = {
            ID: 1,
            Name: 4,
            Type: 2,
            IMDBURL: 4,
            //Notes : 2,
        };
        this.watchListQueueColumnSizes = {
            ID: 2,
            Name: 3,
            Notes: 3,
            Action: 2,
        };
        this.validObjectNames = [
            'WatchList',
            'WatchListItems',
            'WatchListQueue'
        ];
        this.getBackendURL();
        this.getItemsPerPageFilter();
        this.getIncompleteFilter();
        this.getRecordLimitFilter();
        this.getSourceFilter();
        this.getTypeFilter();
        this.getIMDBURLMissingFilter();
    }
    addWatchList(currWatchList) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpParams();
        params = params.append('WatchListItemID', currWatchList.WatchListItemID);
        params = params.append('StartDate', String(currWatchList.StartDate));
        if (currWatchList.EndDate !== null && String(currWatchList.EndDate) !== '') {
            params = params.append('EndDate', String(currWatchList.EndDate));
        }
        if (currWatchList.WatchListSourceID !== null && String(currWatchList.WatchListSourceID) !== '') {
            params = params.append('WatchListSourceID', currWatchList.WatchListSourceID);
        }
        if (currWatchList.Season !== null && String(currWatchList.Season) !== '') {
            params = params.append('Season', currWatchList.Season);
        }
        if (currWatchList.Notes !== null && currWatchList.Notes !== '') {
            params = params.append('Notes', currWatchList.Notes);
        }
        return this.runRest(`/AddWatchList`, 'PUT', params);
    }
    addWatchListItem(currWatchListItem) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpParams();
        params = params.append('WatchListItemName', currWatchListItem.WatchListItemName);
        params = params.append('WatchListTypeID', currWatchListItem.WatchListTypeID);
        if (currWatchListItem.IMDB_URL !== null && currWatchListItem.IMDB_URL !== '') {
            params = params.append('IMDB_URL', currWatchListItem.IMDB_URL);
        }
        if (currWatchListItem.IMDB_Poster !== null && currWatchListItem.IMDB_Poster !== '') {
            params = params.append('IMDB_Poster', currWatchListItem.IMDB_Poster);
        }
        if (currWatchListItem.ItemNotes !== null && currWatchListItem.ItemNotes !== '') {
            params = params.append('ItemNotes', currWatchListItem.ItemNotes);
        }
        return this.runRest(`/AddWatchListItem`, 'PUT', params);
    }
    addWatchListQueueItem(currWatchListQueue) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpParams();
        params = params.append('WatchListItemID', currWatchListQueue.watchListItemID);
        if (currWatchListQueue.notes !== null && currWatchListQueue.notes !== '') {
            params = params.append('Notes', currWatchListQueue.notes);
        }
        return this.runRest(`/AddWatchListQueueItem`, 'PUT', params);
    }
    alert(message) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Alert',
                subHeader: '',
                message: message,
                buttons: ['OK'],
            });
            yield alert.present();
        });
    }
    autoAddWatchListRecord(iMDB_URL = null) {
        const ids = this.watchListItems.map((thisWatchList) => { return thisWatchList.WatchListItemID; });
        const newID = Math.max(...ids) + 1;
        const existing = this.watchListItems.filter((wli) => wli.IMDB_URL === iMDB_URL)[0];
        const currWatchList = [];
        currWatchList.WatchListItemID = (typeof existing !== 'undefined' ? existing.WatchListItemID : newID);
        this.detailWatchListItemID = currWatchList.WatchListItemID;
        this.confirmDialog(currWatchList, 'Do you want to add a Watchlist record now ?', this.showWatchListDetail.bind(this));
    }
    closeOverlay() {
        this.router.navigateByUrl(`/tabs/${this.detailObjectName}`);
        this.detailObjectName = null;
        this.detailID = null;
    }
    confirmDialog(param, messageStr, callback) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Alert',
                message: messageStr,
                buttons: ['OK', 'Cancel']
            });
            this.authGuardDisabled = true;
            yield alert.present();
            const { role } = yield alert.onDidDismiss();
            if (role !== 'cancel') { // OK
                callback(param);
            }
            else {
                this.authGuardDisabled = false;
            }
        });
    }
    deleteWatchList(watchListID) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpParams();
        params = params.append('WatchListID', watchListID);
        return this.runRest(`/DeleteWatchList`, 'PUT', params);
    }
    deleteWatchListItem(watchListItemID) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpParams();
        params = params.append('WatchListItemID', watchListItemID);
        return this.runRest(`/DeleteWatchListItem`, 'PUT', params);
    }
    deleteWatchListQueueItem(watchListQueueItemID) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpParams();
        params = params.append('WatchListQueueItemID', watchListQueueItemID);
        return this.runRest(`/DeleteWatchListQueueItem`, 'PUT', params);
    }
    getBackendURL() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            yield this.storage.create();
            let url = '';
            try {
                url = yield this.storage.get('BackEndURL');
            }
            catch (e) {
            }
            if (url !== null && url.length > 0 && url.endsWith('/')) {
                url = url.slice(0, -1);
            }
            if (typeof this.userData !== 'undefined') {
                this.userData.BackendURL = url;
            }
            else {
                this.userData = this.iUserEmpty();
                this.userData.BackendURL = window.location.origin;
            }
            this.loginWorkflow();
        });
    }
    getColumnSize(columnName, component) {
        if (component === 'WatchList') {
            return this.watchListColumnSizes[columnName];
        }
        else if (component === 'WatchListItems') {
            return this.watchListItemsColumnSizes[columnName];
        }
        else if (component === 'WatchListQueueItems') {
            return this.watchListQueueColumnSizes[columnName];
        }
    }
    getDetailID() {
        return this.detailID;
    }
    getDetailObject() {
        if (this.detailObjectName === null) {
            return null;
        }
        switch (this.detailObjectName) {
            case 'watchlist':
                return this.watchList.filter((wl) => wl.WatchListID === this.detailID)[0];
            case 'watchlist-items':
                return this.watchListItems.filter((wli) => wli.WatchListItemID === this.detailID)[0];
            case 'watchlist-queue':
                return this.watchListQueue.filter((wlq) => wlq.WatchListQueueItemID === this.detailID)[0];
        }
    }
    getDetailObjectName() {
        return this.detailObjectName;
    }
    getDetailWatchListItemID() {
        return this.detailWatchListItemID;
    }
    getIMDBSearchEnabled() {
        return this.runRest(`/IsIMDBSearchEnabled`, 'GET', null);
    }
    getIMDBSearchEnabledSubscription() {
        this.getIMDBSearchEnabled().subscribe((response) => {
            this.isIMDBSearchEnabled = response;
            this.getWatchListSubscription(); // Load WatchList
        }, error => {
            this.handleError(`The error "${error.error}" occurred while getting the IMDB Search enabled status`);
        });
    }
    getIMDBURLMissingFilter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            this.imdb_url_missing = yield this.storage.get('IMDBURLMissingFilter');
        });
    }
    getIMDBURL(watchListItemID) {
        if (this.getWatchListItems.length === 0) {
            return;
        }
        try {
            for (let i = 0; i < this.watchListNames.length; i++) {
                if (this.watchListItems[i].WatchListItemID === watchListItemID && this.watchListItems[i].IMDB_URL !== null) {
                    return this.watchListItems[i].IMDB_URL;
                }
            }
        }
        catch (e) {
            return null;
        }
        return null;
    }
    getRecordLimitFilter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            this.recordLimit = yield this.storage.get('RecordLimitFilter');
        });
    }
    getItemsPerPageFilter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            this.itemsPerPage = yield this.storage.get('ItemsPerPage');
            if (this.itemsPerPage === null) {
                this.itemsPerPage = 20;
            }
        });
    }
    getIncompleteFilter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            this.incompleteFilter = yield this.storage.get('IncompleteFilter');
        });
    }
    getSortClass(columnName, sortDirection, activeSortColumn) {
        const icons = {
            "ID": "IDArrowIcon",
            "Name": "NameArrowIcon",
            "StartDate": "StartDateArrowIcon",
            "EndDate": "EndDateArrowIcon",
            "WatchListSourceID": "SourceArrowIcon",
            "WatchListTypeID": "TypeArrowIcon",
            "IMDB_URL": "IMDBURLArrowIcon"
        };
        const className = (sortDirection === 'ASC' ? "upArrow " : "downArrow ") +
            icons[columnName] + " " +
            (activeSortColumn === columnName ? "active " : "") +
            "header";
        return className;
    }
    getSortIconName(sortDirection) {
        if (typeof sortDirection === 'undefined')
            return;
        return (sortDirection === "ASC" ? "caret-up-outline" : "caret-down-outline");
    }
    getSourceFilter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            this.sourceFilter = yield this.storage.get('SourceFilter');
        });
    }
    getSourceName(sourceID) {
        try {
            return this.watchListSources.filter((wls) => wls.WatchListSourceID === sourceID)[0].WatchListSourceName;
        }
        catch (e) {
            return '';
        }
    }
    getTypeFilter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            this.typeFilter = yield this.storage.get('TypeFilter');
        });
    }
    getWatchList() {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpParams();
        if (this.watchListSortColumn !== null && this.watchListSortDirection !== null) {
            params = params.append('SortColumn', this.watchListSortColumn);
            params = params.append('SortDirection', this.watchListSortDirection);
        }
        return this.runRest(`/GetWatchList`, 'GET', params);
    }
    getWatchListItemName(watchListItemID) {
        try {
            for (let i = 0; i < this.watchListNames.length; i++) {
                if (this.watchListNames[i].WatchListItemID === watchListItemID) {
                    return this.watchListNames[i].WatchListItemName;
                }
            }
        }
        catch (e) {
            return null;
        }
        return null;
    }
    getWatchListItems(loadAllData) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpParams();
        if (this.watchListSortColumn !== null && this.watchListSortDirection !== null) {
            params = params.append('SortColumn', this.watchListItemsSortColumn);
            params = params.append('SortDirection', this.watchListItemsSortDirection);
        }
        return this.runRest(`/GetWatchListItems`, 'GET', params);
    }
    getWatchListItemsSubscription(loadAllData) {
        if (this.isError)
            return;
        this.getWatchListItems(loadAllData).subscribe((response) => {
            if (response === null || (response.length === 1 && response[0] === 'ERROR')) {
                if (response !== null) {
                    this.alert(`The error ${response[1]} occurred`);
                }
                return;
            }
            if (response !== null) {
                for (let i = 0; i < response.length; i++) {
                    response[i].Disabled = true;
                }
            }
            this.watchListItems = response;
            if (this.watchListNames === null || loadAllData === true) {
                this.watchListNames = response;
            }
            this.getWatchListQueueSubscription();
        }, error => {
            this.handleError(`The error "${error.error}" occurred while getting the WatchList Items`);
        });
    }
    getWatchListMovieStats() {
        return this.runRest(`/GetWatchListMovieStats`, 'GET', null);
    }
    getWatchListQueue() {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpParams();
        if (this.searchTerm !== null && this.searchTerm !== '') {
            params = params.append('SearchTerm', this.searchTerm);
        }
        return this.runRest(`/GetWatchListQueue`, 'GET', params);
    }
    getWatchListQueueSubscription() {
        if (this.isError)
            return;
        this.getWatchListQueue().subscribe((response) => {
            if (response !== null) {
                for (let i = 0; i < response.length; i++) {
                    response[i].Disabled = true;
                }
            }
            this.watchListQueue = response;
            this.getWatchListTypesSubscription();
        }, error => {
            this.handleError(`The error "${error.error}" occurred while getting the WatchList Queue`);
        });
    }
    getWatchListSources() {
        return this.runRest(`/GetWatchListSources`, 'GET', null);
    }
    getWatchListSourceStats() {
        return this.runRest(`/GetWatchListSourceStats`, 'GET', null);
    }
    getWatchListSourcesSubscription() {
        if (this.isError)
            return;
        this.getWatchListSources().subscribe((response) => {
            this.watchListSources = response;
        }, error => {
            this.handleError(`The error "${error.error}" occurred while getting the WatchList Sources`);
        });
    }
    getWatchListSubscription() {
        if (this.isError)
            return;
        this.getWatchList().subscribe((response) => {
            if (response !== null) {
                for (let i = 0; i < response.length; i++) {
                    response[i].Disabled = true;
                }
            }
            this.watchList = response;
            this.getWatchListItemsSubscription(true); // Load WatchList Items
        }, error => {
            this.handleError(`The error "${error.error}" occurred while getting the WatchList`);
        });
    }
    getWatchListTopRatedStats() {
        return this.runRest(`/GetWatchListTopRatedStats`, 'GET', null);
    }
    getWatchListTVStats() {
        return this.runRest(`/GetWatchListTVStats`, 'GET', null);
    }
    getWatchListTypeName(watchListTypeID) {
        var _a;
        if (typeof this.watchListTypes === 'undefined') {
            return;
        }
        const typeObj = (_a = this.watchListTypes) === null || _a === void 0 ? void 0 : _a.filter((wlt) => wlt.WatchListTypeID === watchListTypeID)[0];
        if (typeof typeObj !== 'undefined') {
            return typeObj.WatchListTypeName;
        }
        else {
            return null;
        }
    }
    getWatchListTypeNameByWatchListItemID(watchListItemID) {
        if (watchListItemID === 0) {
            return;
        }
        // If watchListItems or watchListTypes are not loaded, this will throw an error
        try {
            // Get type of current watchlist item ID
            const currentWatchListItem = this.watchListItems.filter((wli) => String(wli.WatchListItemID) === String(watchListItemID))[0];
            if (currentWatchListItem !== null) {
                const typeObj = this.watchListTypes.filter((wlt) => {
                    return wlt.WatchListTypeID === currentWatchListItem.WatchListTypeID;
                })[0];
                if (typeObj !== null) {
                    return typeObj.WatchListTypeName;
                }
                else {
                    return null;
                }
            }
            else {
                return null;
            }
        }
        catch (e) {
        }
    }
    getWatchListTypes() {
        return this.runRest(`/GetWatchListTypes`, 'GET', null);
    }
    getWatchListTypesSubscription() {
        if (this.isError)
            return;
        this.getWatchListTypes().subscribe((response) => {
            this.watchListTypes = response;
            this.getWatchListSourcesSubscription();
        }, error => {
            this.handleError(`The error "${error.error}" occurred while getting the WatchList Types`);
        });
    }
    handleError(error) {
        this.isError = true;
        console.log(error);
        this.alert(error);
        if (error.error === 'Unauthorized') {
            console.log('Unauthorized. Check the Auth Key');
        }
        else if (error.error instanceof Error) {
            const errMessage = error.error.message;
            return (0,rxjs___WEBPACK_IMPORTED_MODULE_3__.throwError)(errMessage);
            // Use the following instead if using lite-server
            // return Observable.throw(err.text() || 'backend server error');
        }
        return (0,rxjs___WEBPACK_IMPORTED_MODULE_3__.throwError)(error || 'Node.js server error');
    }
    isBackendURLSet() {
        return (typeof this.userData !== 'undefined'
            && this.userData.BackendURL !== null
            && this.userData.BackendURL !== ''
            ? true : false);
    }
    ;
    iUserEmpty() {
        return {
            UserID: 0,
            Username: '',
            Password: '',
            Realname: '',
            BackendURL: '',
        };
    }
    iWatchListEmpty() {
        return {
            WatchListID: null,
            UserID: null,
            WatchListItemID: null,
            StartDate: null,
            EndDate: null,
            WatchListSourceID: null,
            Season: null,
            Rating: null,
            IMDB_Poster: null,
            Notes: null
        };
    }
    iWatchListItemEmpty() {
        return {
            WatchListItemID: null,
            WatchListItemName: null,
            WatchListTypeID: null,
            IMDB_URL: null,
            IMDB_Poster: null,
            ItemNotes: null,
            Previous: null
        };
    }
    iWatchListQueueItemEmpty() {
        return {
            WatchListQueueItemID: null,
            UserID: null,
            WatchListItemID: null,
            Notes: null,
            Previous: null
        };
    }
    iWatchListSourceEmpty() {
        return {
            WatchListSourceID: null,
            WatchListSourceName: null
        };
    }
    iWatchListTypeEmpty() {
        return {
            WatchListTypeID: null,
            WatchListTypeName: null
        };
    }
    login() {
        const headers = {
            headers: {
                wl_username: (typeof this.userData !== 'undefined' ? this.userData.Username : ''),
                wl_password: (typeof this.userData !== 'undefined' ? this.userData.Password : ''),
            },
            withCredentials: true
        };
        return this.http.put(`${this.userData.BackendURL}/Login`, null, headers);
    }
    loginSubscription(username, password, backendURL) {
        if (typeof this.userData !== 'undefined') {
            this.userData.Username = username;
            this.userData.Password = password;
            if (backendURL !== null && backendURL !== '') {
                this.userData.BackendURL = backendURL;
            }
        }
        if (backendURL !== null && backendURL !== '') {
            this.setBackendURL();
        }
        this.login().subscribe((response) => {
            if (response[0] === 'OK') {
                this.loginSuccessfullActions(response[1]);
            }
            else {
                this.alert('Login failed. Please check your username and password');
            }
        }, error => {
            this.alert('Login failed. Please check your username and password');
            this.router.navigateByUrl('/tabs/login');
        });
    }
    loginSuccessfullActions(response) {
        this.isLoggedIn = true;
        try { // when check if logged in already, user payload is not present so ignore any errors
            if (typeof response[0].UserID !== 'undefined' && typeof this.userData !== 'undefined') {
                this.userData.UserID = response[0].UserID;
            }
            if (typeof response[0].Username !== 'undefined' && typeof this.userData !== 'undefined') {
                this.userData.Username = response[0].Username;
            }
            if (typeof response[0].Realname !== 'undefined' && typeof this.userData !== 'undefined') {
                this.userData.Realname = response[0].Realname;
            }
            if (typeof response[0].Realname !== 'undefined' && typeof this.userData !== 'undefined') {
                this.userData.Realname = response[0].Realname;
            }
            if (typeof response[0].BackEndURL !== 'undefined' && typeof this.userData !== 'undefined') {
                this.userData.BackendURL = response[0].BackendURL;
                this.setBackendURL();
            }
        }
        catch (err) { }
        this.getIMDBSearchEnabledSubscription();
        this.router.navigateByUrl('/tabs/watchlist');
    }
    loginWorkflow() {
        // This gets called after the backend URL is set
        if (this.userData.BackendURL === null || this.userData.BackendURL === '') {
            this.isLoggedInCheckComplete = true;
            this.router.navigateByUrl('/tabs/login');
            return;
        }
        else {
            const headers = {
                withCredentials: true
            };
            this.http.get(`${this.userData.BackendURL}/IsLoggedIn`, headers).subscribe((response) => {
                var isLoggedIn = response[1];
                this.isLoggedInCheckComplete = true;
                if (isLoggedIn === null) {
                    this.router.navigateByUrl('/tabs/login');
                }
                else {
                    this.loginSuccessfullActions(response[1]);
                }
            }, error => {
                this.isLoggedInCheckComplete = true;
                this.router.navigateByUrl('/tabs/login');
            });
        }
    }
    openDetailOverlay(objectName, objectID) {
        if (this.detailObjectName !== null) { // Ignore because overlay is already open
            return;
        }
        if (objectName === null) {
            this.alert(`objectName not provided`);
            return;
        }
        if (this.validObjectNames[objectName] === null) {
            this.alert(`Invalid objectName ${objectName}`);
            return;
        }
        this.detailObjectName = objectName;
        this.detailID = objectID;
        this.router.navigate(['/tabs/detail-overlay', { ObjectName: objectName }]);
    }
    pullToRefresh(event, component) {
        setTimeout(() => {
            if (component === 'WatchList') {
                this.getWatchList().subscribe((response) => {
                    if (response !== null) {
                        for (let i = 0; i < response.length; i++) {
                            response[i].Disabled = true;
                        }
                    }
                    this.watchList = response;
                    event.target.complete();
                }, error => {
                    this.alert(`An error occurred getting the Watchlist ${error}`);
                });
            }
            else if (component === 'WatchListItems') {
                this.getWatchListItems(true).subscribe((response) => {
                    if (response !== null) {
                        for (let i = 0; i < response.length; i++) {
                            response[i].Disabled = true;
                        }
                    }
                    this.watchListItems = response;
                    event.target.complete();
                }, error => {
                    this.alert(`An error occurred getting the Watchlist Items ${error}`);
                });
            }
            else if (component === 'WatchListQueueItems') {
                this.getWatchListQueue().subscribe((response) => {
                    if (response !== null) {
                        for (let i = 0; i < response.length; i++) {
                            response[i].Disabled = true;
                        }
                    }
                    this.watchListQueue = response;
                    event.target.complete();
                }, error => {
                    this.alert(`An error occurred getting the Watchlist Queue ${error}`);
                });
            }
        }, 2000);
    }
    runRest(path, verb, params) {
        if (params === null) {
            params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpParams();
        }
        const headers = {
            withCredentials: true
        };
        if (typeof this.userData !== 'undefined' && this.userData.BackendURL.endsWith('/')) {
            this.userData.BackendURL = this.userData.BackendURL.slice(0, -1);
        }
        switch (verb) {
            case 'GET':
                return this.http.get(this.userData.BackendURL + path + (params !== null ? '?' + params : ''), headers);
            case 'PUT':
                return this.http.put(this.userData.BackendURL + path + (params !== null ? '?' + params : ''), null, headers);
        }
    }
    saveIMDBURLMissingFilter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            yield this.storage.set('IMDBURLMissingFilter', this.imdb_url_missing);
        });
    }
    saveIncompleteFilter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            yield this.storage.set('IncompleteFilter', this.incompleteFilter);
        });
    }
    saveItemsPerPageFilter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            yield this.storage.set('ItemsPerPage', this.itemsPerPage);
        });
    }
    saveRecordLimitFilter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            yield this.storage.set('RecordLimitFilter', this.recordLimit);
        });
    }
    saveSourceFilter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            yield this.storage.set('SourceFilter', this.sourceFilter);
        });
    }
    saveTypeFilter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            yield this.storage.set('TypeFilter', this.typeFilter);
        });
    }
    searchIMDB(searchTerm) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpParams();
        if (searchTerm !== '') {
            params = params.append('SearchTerm', searchTerm);
        }
        return this.runRest(`/SearchIMDB`, 'GET', params);
    }
    searchTermChangeHandler(event) {
        if (event !== null)
            this.setSearchTerm(event.target.value);
    }
    setBackendURL() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            if (this.userData.BackendURL !== null && this.userData.BackendURL !== '') {
                // Remove trailing slash
                const url = (this.userData.BackendURL.endsWith('/') ? this.userData.BackendURL.slice(0, -1)
                    : this.userData.BackendURL);
                yield this.storage.set('BackEndURL', url);
            }
            else {
                yield this.storage.remove('BackEndURL');
                this.watchList = [];
                this.watchListItems = [];
                this.watchListSources = [];
                this.watchListTypes = [];
            }
        });
    }
    setWatchList(newWatchList) {
        this.watchList = newWatchList;
    }
    setSearchTerm(newSearchTerm) {
        this.searchTerm = newSearchTerm;
    }
    setWatchListItems(newWatchListItems) {
        this.watchListItems = newWatchListItems;
    }
    showWatchListDetail(currWatchList) {
        // This is activated after adding a WatchListItem when you say yes to add a WatchList item now prompt
        this.openDetailOverlay('watchlist', currWatchList.WatchListItemID);
    }
    sortClick(name, direction, component) {
        if (component === 'WatchList') {
            this.watchListSortColumn = name;
            this.watchListSortActiveColumn = name;
            if (direction === 'ASC') {
                this.watchListSortDirection = 'DESC';
            }
            else {
                this.watchListSortDirection = 'ASC';
            }
            this.getWatchListSubscription(); // Reload WatchList after user clicks on sort icons
        }
        else if (component === 'WatchListItems') {
            this.watchListItemsSortColumn = name;
            this.watchListItemsSortActiveColumn = name;
            if (direction === 'ASC') {
                this.watchListItemsSortDirection = 'DESC';
            }
            else {
                this.watchListItemsSortDirection = 'ASC';
            }
            this.getWatchListItemsSubscription(false); // Reload WatchListItems after user clicks on sort icons
        }
    }
    trackByFn(index) {
        return index; // or item.id
    }
    updateWatchList(currWatchList) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpParams();
        params = params.append('WatchListID', currWatchList === null || currWatchList === void 0 ? void 0 : currWatchList.WatchListID);
        params = params.append('WatchListItemID', currWatchList === null || currWatchList === void 0 ? void 0 : currWatchList.WatchListItemID);
        params = params.append('StartDate', String(currWatchList === null || currWatchList === void 0 ? void 0 : currWatchList.StartDate));
        if (currWatchList.EndDate !== null && String(currWatchList.EndDate) !== '') {
            params = params.append('EndDate', String(currWatchList.EndDate));
        }
        if (currWatchList.Season !== null) {
            params = params.append('Season', currWatchList.Season);
        }
        if (currWatchList.WatchListSourceID !== null) {
            params = params.append('WatchListSourceID', currWatchList.WatchListSourceID);
        }
        if (currWatchList.Rating !== null) {
            params = params.append('Rating', currWatchList.Rating);
        }
        if (currWatchList.Notes !== null && currWatchList.Notes !== '') {
            params = params.append('Notes', currWatchList.Notes);
        }
        return this.runRest(`/UpdateWatchList`, 'PUT', params);
    }
    updateWatchListItem(currWatchListItem) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpParams();
        params = params.append('WatchListItemID', currWatchListItem.WatchListItemID);
        params = params.append('WatchListItemName', currWatchListItem.WatchListItemName);
        params = params.append('WatchListTypeID', currWatchListItem.WatchListTypeID);
        params = params.append('IMDB_URL', currWatchListItem.IMDB_URL);
        params = params.append('IMDB_Poster', currWatchListItem.IMDB_Poster);
        params = params.append('ItemNotes', currWatchListItem.ItemNotes);
        return this.runRest(`/UpdateWatchListItem`, 'PUT', params);
    }
    updateWatchListQueueItem(currWatchListQueueItem) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpParams();
        params = params.append('WatchListQueueItemID', currWatchListQueueItem.WatchListQueueItemID);
        params = params.append('WatchListItemID', currWatchListQueueItem.WatchListItemID);
        if (currWatchListQueueItem.Notes !== null && currWatchListQueueItem.Notes !== '') {
            params = params.append('Notes', currWatchListQueueItem.Notes);
        }
        return this.runRest(`/UpdateWatchListQueueItem`, 'PUT', params);
    }
    watchListItemExists(itemName) {
        for (let i = 0; i < this.watchListItems.length; i++) {
            if (this.watchListItems[i].watchListItemName === itemName) {
                return true;
            }
        }
        return false;
    }
};
DataService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.AlertController },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_0__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ToastController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router }
];
DataService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Injectable)({
        providedIn: `root`,
    })
], DataService);



/***/ }),

/***/ 2340:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": () => (/* binding */ environment)
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ 4431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ 8150);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 6747);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 2340);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
(0,_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__.platformBrowserDynamic)().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)
    .catch(err => console.log(err));


/***/ }),

/***/ 863:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./ion-accordion_2.entry.js": [
		79,
		"common",
		"node_modules_ionic_core_dist_esm_ion-accordion_2_entry_js"
	],
	"./ion-action-sheet.entry.js": [
		5593,
		"common",
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		3225,
		"common",
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		4812,
		"common",
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		6655,
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		4856,
		"common",
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		3059,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-breadcrumb_2.entry.js": [
		8648,
		"common",
		"node_modules_ionic_core_dist_esm_ion-breadcrumb_2_entry_js"
	],
	"./ion-button_2.entry.js": [
		8308,
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		4690,
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		4090,
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		6214,
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		9447,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime-button.entry.js": [
		7950,
		"default-node_modules_ionic_core_dist_esm_data-cb72448c_js-node_modules_ionic_core_dist_esm_th-29e28e",
		"node_modules_ionic_core_dist_esm_ion-datetime-button_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		9689,
		"default-node_modules_ionic_core_dist_esm_data-cb72448c_js-node_modules_ionic_core_dist_esm_th-29e28e",
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		8840,
		"common",
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		749,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		9667,
		"common",
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input.entry.js": [
		3288,
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		5473,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		3634,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		2855,
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		495,
		"common",
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		8737,
		"common",
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		9632,
		"common",
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-picker-column-internal.entry.js": [
		4446,
		"common",
		"node_modules_ionic_core_dist_esm_ion-picker-column-internal_entry_js"
	],
	"./ion-picker-internal.entry.js": [
		2275,
		"node_modules_ionic_core_dist_esm_ion-picker-internal_entry_js"
	],
	"./ion-popover.entry.js": [
		8050,
		"common",
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		8994,
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		3592,
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		5454,
		"common",
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		290,
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		2666,
		"common",
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		4816,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		5534,
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		4902,
		"common",
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment_2.entry.js": [
		1938,
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select_3.entry.js": [
		8179,
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-slide_2.entry.js": [
		668,
		"node_modules_ionic_core_dist_esm_ion-slide_2_entry_js"
	],
	"./ion-spinner.entry.js": [
		1624,
		"common",
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		9989,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		8902,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		199,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		8395,
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		6357,
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		8268,
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		5269,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	],
	"./ion-virtual-scroll.entry.js": [
		2875,
		"node_modules_ionic_core_dist_esm_ion-virtual-scroll_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(() => {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 863;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 9259:
/*!***********************************************!*\
  !*** ./src/app/app.component.scss?ngResource ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = "#backendURL {\n  margin-top: 25px;\n}\n\n#backendURLInput {\n  border-style: dashed;\n  border-width: 1px;\n}\n\n#rowsLabel {\n  margin-top: 10px;\n}\n\n#rowsLabel ion-label {\n  margin-left: 17px;\n}\n\n.align {\n  padding-top: 20px;\n}\n\n.credentialInput {\n  border-style: dashed;\n  border-width: 1px;\n}\n\n.optionsIcon {\n  width: 45px;\n  height: 45px;\n  cursor: pointer;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGdCQUFBO0FBQ0o7O0FBRUE7RUFDSyxvQkFBQTtFQUNBLGlCQUFBO0FBQ0w7O0FBRUE7RUFDSSxnQkFBQTtBQUNKOztBQUVBO0VBQ0ksaUJBQUE7QUFDSjs7QUFFQTtFQUNJLGlCQUFBO0FBQ0o7O0FBRUE7RUFDSSxvQkFBQTtFQUNBLGlCQUFBO0FBQ0o7O0FBRUE7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7QUFDSiIsImZpbGUiOiJhcHAuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIjYmFja2VuZFVSTCB7XHJcbiAgICBtYXJnaW4tdG9wOiAyNXB4O1xyXG59XHJcblxyXG4jYmFja2VuZFVSTElucHV0IHtcclxuICAgICBib3JkZXItc3R5bGU6IGRhc2hlZDtcclxuICAgICBib3JkZXItd2lkdGg6IDFweDtcclxufVxyXG5cclxuI3Jvd3NMYWJlbCB7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG59XHJcblxyXG4jcm93c0xhYmVsIGlvbi1sYWJlbCB7XHJcbiAgICBtYXJnaW4tbGVmdDogMTdweDtcclxufVxyXG5cclxuLmFsaWduIHtcclxuICAgIHBhZGRpbmctdG9wOjIwcHg7XHJcbn1cclxuXHJcbi5jcmVkZW50aWFsSW5wdXQge1xyXG4gICAgYm9yZGVyLXN0eWxlOiBkYXNoZWQ7XHJcbiAgICBib3JkZXItd2lkdGg6IDFweDtcclxufVxyXG5cclxuLm9wdGlvbnNJY29uIHtcclxuICAgIHdpZHRoOjQ1cHg7XHJcbiAgICBoZWlnaHQ6IDQ1cHg7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn0iXX0= */";

/***/ }),

/***/ 3964:
/*!*******************************************************************************!*\
  !*** ./src/app/components/detail-overlay/detail-overlay.page.scss?ngResource ***!
  \*******************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "@media screen and (min-width: 320px) and (max-width: 480px) {\n  /* styles */\n}\n.content {\n  height: 92%;\n  width: 600px;\n  background-color: lightgrey;\n  border-style: solid;\n  border-style: ridge;\n}\nion-icon {\n  width: 35px;\n  height: 35px;\n  cursor: pointer;\n}\napp-watchlist-detail, app-watchlist-items-detail, app-watchlist-queue-detail {\n  color: black;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldGFpbC1vdmVybGF5LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7QUFDSjtBQUVBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSwyQkFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7QUFBSjtBQUdBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0FBQUo7QUFHQTtFQUNJLFlBQUE7QUFBSiIsImZpbGUiOiJkZXRhaWwtb3ZlcmxheS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJAbWVkaWEgc2NyZWVuIGFuZCAobWluLXdpZHRoOiAzMjBweCkgYW5kIChtYXgtd2lkdGg6IDQ4MHB4KXtcclxuICAgIC8qIHN0eWxlcyAqL1xyXG59XHJcblxyXG4uY29udGVudCB7XHJcbiAgICBoZWlnaHQ6IDkyJTtcclxuICAgIHdpZHRoOiA2MDBweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IGxpZ2h0Z3JleTtcclxuICAgIGJvcmRlci1zdHlsZTogc29saWQ7XHJcbiAgICBib3JkZXItc3R5bGU6IHJpZGdlO1xyXG59XHJcblxyXG5pb24taWNvbiB7ICBcclxuICAgIHdpZHRoOiAzNXB4O1xyXG4gICAgaGVpZ2h0OiAzNXB4O1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcblxyXG5hcHAtd2F0Y2hsaXN0LWRldGFpbCwgYXBwLXdhdGNobGlzdC1pdGVtcy1kZXRhaWwsIGFwcC13YXRjaGxpc3QtcXVldWUtZGV0YWlsIHtcclxuICAgIGNvbG9yOiBibGFjaztcclxufSJdfQ== */";

/***/ }),

/***/ 6632:
/*!***********************************************************************************!*\
  !*** ./src/app/components/watchlist-detail/watchlist-detail.page.scss?ngResource ***!
  \***********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "ion-icon {\n  width: 35px;\n  height: 35px;\n  cursor: pointer;\n}\n\n#addToQueue {\n  cursor: pointer;\n}\n\nion-input {\n  border-style: dashed;\n  border-width: 1px;\n}\n\n#action_row {\n  position: absolute;\n  bottom: 0;\n  left: 0;\n}\n\n#deleteIcon {\n  position: absolute;\n  bottom: 0;\n  right: 0;\n}\n\n.editAddSelect {\n  background-color: white;\n}\n\n.nooutline {\n  outline: none !important;\n}\n\n.poster {\n  max-height: 125px;\n}\n\n.shortField {\n  max-width: 75px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndhdGNobGlzdC1kZXRhaWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0FBQ0o7O0FBRUE7RUFDSSxlQUFBO0FBQ0o7O0FBRUE7RUFDSSxvQkFBQTtFQUNBLGlCQUFBO0FBQ0o7O0FBRUE7RUFDSSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxPQUFBO0FBQ0o7O0FBRUE7RUFDSSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxRQUFBO0FBQ0o7O0FBRUE7RUFDSSx1QkFBQTtBQUNKOztBQUVBO0VBQ0ksd0JBQUE7QUFDSjs7QUFFQTtFQUNLLGlCQUFBO0FBQ0w7O0FBRUE7RUFDSSxlQUFBO0FBQ0oiLCJmaWxlIjoid2F0Y2hsaXN0LWRldGFpbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taWNvbiB7ICBcclxuICAgIHdpZHRoOiAzNXB4O1xyXG4gICAgaGVpZ2h0OiAzNXB4O1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcblxyXG4jYWRkVG9RdWV1ZSB7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbmlvbi1pbnB1dCB7XHJcbiAgICBib3JkZXItc3R5bGU6IGRhc2hlZDtcclxuICAgIGJvcmRlci13aWR0aDogMXB4O1xyXG59XHJcblxyXG4jYWN0aW9uX3JvdyB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBib3R0b206IDA7XHJcbiAgICBsZWZ0OiAwO1xyXG59XHJcblxyXG4jZGVsZXRlSWNvbiB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBib3R0b206IDA7XHJcbiAgICByaWdodDogMDtcclxufVxyXG5cclxuLmVkaXRBZGRTZWxlY3Qge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbn1cclxuXHJcbi5ub291dGxpbmUge1xyXG4gICAgb3V0bGluZTpub25lICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5wb3N0ZXIge1xyXG4gICAgIG1heC1oZWlnaHQ6IDEyNXB4O1xyXG59XHJcblxyXG4uc2hvcnRGaWVsZCB7XHJcbiAgICBtYXgtd2lkdGg6IDc1cHg7XHJcbn0iXX0= */";

/***/ }),

/***/ 1988:
/*!***********************************************************************************************!*\
  !*** ./src/app/components/watchlist-items-detail/watchlist-items-detail.page.scss?ngResource ***!
  \***********************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "ion-icon {\n  width: 35px;\n  height: 35px;\n  cursor: pointer;\n}\n\nion-input {\n  border-style: dashed;\n  border-width: 1px;\n}\n\n#deleteIcon {\n  position: absolute;\n  bottom: 0;\n  right: 0;\n}\n\n.editAddSelect {\n  background-color: white;\n}\n\n.nooutline {\n  outline: none !important;\n}\n\n.poster {\n  max-height: 125px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndhdGNobGlzdC1pdGVtcy1kZXRhaWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0FBQ0o7O0FBRUE7RUFDSSxvQkFBQTtFQUNBLGlCQUFBO0FBQ0o7O0FBRUE7RUFDSSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxRQUFBO0FBQ0o7O0FBRUE7RUFDSSx1QkFBQTtBQUNKOztBQUVBO0VBQ0ksd0JBQUE7QUFDSjs7QUFFQTtFQUNJLGlCQUFBO0FBQ0oiLCJmaWxlIjoid2F0Y2hsaXN0LWl0ZW1zLWRldGFpbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taWNvbiB7ICBcclxuICAgIHdpZHRoOiAzNXB4O1xyXG4gICAgaGVpZ2h0OiAzNXB4O1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcblxyXG5pb24taW5wdXQge1xyXG4gICAgYm9yZGVyLXN0eWxlOiBkYXNoZWQ7XHJcbiAgICBib3JkZXItd2lkdGg6IDFweDtcclxufVxyXG5cclxuI2RlbGV0ZUljb24ge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgYm90dG9tOiAwO1xyXG4gICAgcmlnaHQ6IDA7XHJcbn1cclxuXHJcbi5lZGl0QWRkU2VsZWN0IHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG59XHJcblxyXG4ubm9vdXRsaW5lIHtcclxuICAgIG91dGxpbmU6bm9uZSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ucG9zdGVyIHtcclxuICAgIG1heC1oZWlnaHQ6IDEyNXB4O1xyXG59Il19 */";

/***/ }),

/***/ 4552:
/*!***********************************************************************************************!*\
  !*** ./src/app/components/watchlist-queue-detail/watchlist-queue-detail.page.scss?ngResource ***!
  \***********************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "ion-icon {\n  width: 35px;\n  height: 35px;\n  cursor: pointer;\n}\n\nion-input {\n  border-style: dashed;\n  border-width: 1px;\n}\n\n#deleteIcon {\n  position: absolute;\n  bottom: 0;\n  right: 0;\n}\n\n.editAddSelect {\n  background-color: white;\n}\n\n.nooutline {\n  outline: none !important;\n}\n\n.poster {\n  max-height: 125px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndhdGNobGlzdC1xdWV1ZS1kZXRhaWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0FBQ0o7O0FBRUE7RUFDSSxvQkFBQTtFQUNBLGlCQUFBO0FBQ0o7O0FBRUE7RUFDSSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxRQUFBO0FBQ0o7O0FBRUE7RUFDSSx1QkFBQTtBQUNKOztBQUVBO0VBQ0ksd0JBQUE7QUFDSjs7QUFFQTtFQUNJLGlCQUFBO0FBQ0oiLCJmaWxlIjoid2F0Y2hsaXN0LXF1ZXVlLWRldGFpbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taWNvbiB7ICBcclxuICAgIHdpZHRoOiAzNXB4O1xyXG4gICAgaGVpZ2h0OiAzNXB4O1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcblxyXG5pb24taW5wdXQge1xyXG4gICAgYm9yZGVyLXN0eWxlOiBkYXNoZWQ7XHJcbiAgICBib3JkZXItd2lkdGg6IDFweDtcclxufVxyXG5cclxuI2RlbGV0ZUljb24ge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgYm90dG9tOiAwO1xyXG4gICAgcmlnaHQ6IDA7XHJcbn1cclxuXHJcbi5lZGl0QWRkU2VsZWN0IHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG59XHJcblxyXG4ubm9vdXRsaW5lIHtcclxuICAgIG91dGxpbmU6bm9uZSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ucG9zdGVyIHtcclxuICAgIG1heC1oZWlnaHQ6IDEyNXB4O1xyXG59Il19 */";

/***/ }),

/***/ 3383:
/*!***********************************************!*\
  !*** ./src/app/app.component.html?ngResource ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-app>\r\n     <ion-menu *ngIf=\"dataService.isBackendURLSet() && dataService.isLoggedIn\" contentId=\"main-content\" type=\"push\"> \r\n          <ion-header> \r\n               <ion-toolbar> \r\n                    <ion-title>Menu</ion-title> \r\n               </ion-toolbar> \r\n          </ion-header> \r\n\r\n          <ion-content>\r\n               <ion-grid *ngIf=\"!dataService.isError\">\r\n                    <ion-row>\r\n                         <ion-col size=\"3\" id=\"rowsLabel\">\r\n                              <ion-label>Rows</ion-label>\r\n                         </ion-col>\r\n\r\n                         <ion-col size=\"9\">\r\n                              <ion-select placeholder='Record Limit' name=\"recordLimit\" [(ngModel)]=\"dataService.recordLimit\" (ionChange)=\"optionChangeHandler($event)\">\r\n                                   <ion-select-option *ngFor=\"let currItem of recordLimitOptions;trackBy: trackByFn\" [value]=\"currItem\">{{currItem}}</ion-select-option>\r\n                              </ion-select>\r\n                         </ion-col>\r\n\r\n                         <ion-col size=\"3\" id=\"rowsLabel\">\r\n                              <ion-label>Items per page</ion-label>\r\n                         </ion-col>\r\n\r\n                         <ion-col size=\"9\">\r\n                              <ion-select placeholder='Items per page' name=\"itemsPerPage\" [(ngModel)]=\"dataService.itemsPerPage\" (ionChange)=\"optionChangeHandler($event)\">\r\n                                   <ion-select-option *ngFor=\"let currItem of itemsPerPage;trackBy: trackByFn\" [value]=\"currItem\">{{currItem}}</ion-select-option>\r\n                              </ion-select>\r\n                         </ion-col>\r\n\r\n                         <ion-col size=\"12\" *ngIf=\"currentRoute==='WatchList'\">\r\n                              <ion-item>Still watching<ion-toggle [(ngModel)]=\"dataService.incompleteFilter\" color=\"primary\" (ionChange)=\"optionChangeHandler($event)\"></ion-toggle></ion-item>\r\n                         </ion-col>\r\n\r\n                         <ion-col size=\"12\" *ngIf=\"currentRoute==='WatchListItems'\">\r\n                              <ion-item>IMDB URL Missing<ion-toggle id=\"IMDBURLMissing\" [(ngModel)]=\"dataService.imdb_url_missing\" color=\"primary\" (ionChange)=\"optionChangeHandler($event)\"></ion-toggle></ion-item>\r\n                         </ion-col>\r\n\r\n                         <ion-col size=\"12\" *ngIf=\"currentRoute==='WatchList'\">\r\n                              <ion-select placeholder='Source' name=\"source\" [(ngModel)]=\"dataService.sourceFilter\" (ionChange)=\"optionChangeHandler($event)\">\r\n                                   <ion-select-option value=\"All\">All</ion-select-option>\r\n                                   <ion-select-option *ngFor=\"let currItem of dataService.watchListSources;trackBy: trackByFn\" [value]=\"currItem['WatchListSourceID']\" (ionChange)=\"optionChangeHandler($event)\">{{currItem['WatchListSourceName']}}</ion-select-option>\r\n                              </ion-select>\r\n                         </ion-col>\r\n\r\n                         <ion-col size=\"12\" *ngIf=\"currentRoute==='WatchList'\">\r\n                              <ion-select placeholder='Type' name=\"type\" [(ngModel)]=\"dataService.typeFilter\" (ionChange)=\"optionChangeHandler($event)\">\r\n                                   <ion-select-option value=\"All\">All</ion-select-option>\r\n                                   <ion-select-option *ngFor=\"let currItem of dataService.watchListTypes;trackBy: trackByFn\" [value]=\"currItem['WatchListTypeID']\" (ionChange)=\"optionChangeHandler($event)\">{{currItem['WatchListTypeName']}}</ion-select-option>\r\n                              </ion-select>\r\n                         </ion-col>\r\n                    </ion-row>\r\n\r\n                    <ion-row *ngIf=\"!isEditingOptions\">\r\n                         <ion-col size=\"12\"></ion-col>\r\n                         <ion-col size=\"12\"></ion-col>\r\n                         <ion-col size=\"12\"></ion-col>\r\n\r\n                         <ion-col size=\"3\" class=\"align\">\r\n                              Sign Out\r\n                         </ion-col>\r\n                         <ion-col size=\"2\">\r\n                              <ion-icon class=\"optionsIcon\" name=\"log-out-outline\" (click)=\"signOut()\"></ion-icon>\r\n                         </ion-col> \r\n                    </ion-row>\r\n               </ion-grid>\r\n          </ion-content>\r\n     </ion-menu>\r\n\r\n     <ion-router-outlet id=\"main-content\"></ion-router-outlet>     \r\n</ion-app>\r\n\r\n<!--\r\n<a [routerLink]=\"['/forgot-password']\" class=\"small-text\">Forgot Password?</a>\r\n-->";

/***/ }),

/***/ 2508:
/*!*******************************************************************************!*\
  !*** ./src/app/components/detail-overlay/detail-overlay.page.html?ngResource ***!
  \*******************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<body class=\"content\">\r\n     <app-watchlist-detail *ngIf=\"detailObjectName === 'watchlist'\"></app-watchlist-detail>\r\n\r\n     <app-watchlist-items-detail *ngIf=\"detailObjectName === 'watchlist-items'\"></app-watchlist-items-detail>\r\n\r\n     <app-watchlist-queue-detail *ngIf=\"detailObjectName === 'watchlist-queue'\"></app-watchlist-queue-detail>\r\n</body>";

/***/ }),

/***/ 2971:
/*!***********************************************************************************!*\
  !*** ./src/app/components/watchlist-detail/watchlist-detail.page.html?ngResource ***!
  \***********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-grid>\r\n     <ion-grid>\r\n          <ion-row>\r\n               <ion-col size=\"1\">\r\n                    <ion-icon *ngIf=\"!isAdding && !isEditing\" name=\"create-outline\" (click)=\"editWatchList()\"></ion-icon>\r\n                    <ion-icon *ngIf=\"isAdding || isEditing\" name=\"save-outline\" (click)=\"saveWatchList()\"></ion-icon>\r\n               </ion-col>\r\n  \r\n               <ion-col size=\"1\"></ion-col>\r\n  \r\n               <ion-col size=\"2\">\r\n                    <ion-icon *ngIf=\"isAdding || isEditing\" name=\"close-circle-outline\" (click)=\"cancelWatchList()\"></ion-icon>\r\n               </ion-col>\r\n         \r\n               <ion-col size=\"7\"></ion-col>\r\n  \r\n              <ion-col size=\"1\">\r\n                    <ion-icon *ngIf=\"!isAdding && !isEditing\" name=\"close-outline\" class=\"cancelButton\" (click)=\"closeClickHandler();\"></ion-icon>\r\n               </ion-col>\r\n          </ion-row>\r\n  \r\n          <ion-row>\r\n               <ion-col [size]=\"12\"></ion-col>\r\n          </ion-row>\r\n     </ion-grid>\r\n\r\n     <ion-row>\r\n          <ion-col [size]=\"8\">\r\n               <ion-label>WatchList ID {{ detailObject?.WatchListID }}</ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col [size]=\"4\">\r\n               <ion-label>Type: {{ dataService.getWatchListTypeName(detailObject?.WatchListTypeID) }}</ion-label>\r\n          </ion-col>\r\n     </ion-row>\r\n\r\n     <ion-row id=\"action_row\" *ngIf=\"!isEditing && !isAdding\">\r\n          <ion-col [size]=\"10\">\r\n               <ion-button id=\"addToQueue\" (click)=\"addToWatchListQueue(currWatchList)\">Add to Queue</ion-button>\r\n          </ion-col>\r\n     </ion-row>\r\n\r\n     <ion-row>\r\n          <ion-col [size]=\"6\">\r\n               <a class=\"nooutline\" *ngIf=\"detailObject?.IMDB_URL !== null\" href=\"{{detailObject?.IMDB_URL}}\" target=\"_blank\">\r\n                    <img *ngIf=\"detailObject?.IMDB_Poster !== null\" class=\"poster\" src=\"{{detailObject?.IMDB_Poster}}\">\r\n               </a>\r\n\r\n               <img *ngIf=\"detailObject?.IMDB_URL === null && detailObject?.IMDB_Poster !== null\" class=\"poster\" src=\"{{detailObject?.IMDB_Poster}}\">\r\n          </ion-col>\r\n     </ion-row>\r\n\r\n     <ion-row>\r\n          <ion-col [size]=\"2\">\r\n               <ion-label>Name</ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col [size]=\"1\"></ion-col>\r\n         \r\n          <ion-col [size]=\"9\">\r\n               <ion-label *ngIf=\"!isEditing && !isAdding\">\r\n                    {{ dataService.getWatchListItemName(detailObject?.WatchListItemID) }}\r\n               </ion-label>\r\n\r\n               <select class=\"editAddSelect\" *ngIf=\"isEditing && !isAdding\" placeholder='Name' name=\"title\" type=\"number\" [(ngModel)]=\"detailObject.WatchListItemID\">\r\n                    <option *ngFor=\"let currItem of dataService.watchListNames;trackBy: dataService.trackByFn\" [value]=\"currItem.WatchListItemID\">{{currItem.WatchListItemName}}</option>\r\n               </select>\r\n\r\n               <select class=\"editAddSelect\" *ngIf=\"isAdding\" placeholder='Name' name=\"title\" [(ngModel)]=\"addItemID\">\r\n                    <option *ngFor=\"let currItem of dataService.watchListNames;trackBy: dataService.trackByFn\" [value]=\"currItem.WatchListItemID\">{{currItem.WatchListItemName}}</option>\r\n               </select>\r\n          </ion-col>\r\n     </ion-row>\r\n\r\n     <ion-row>\r\n          <ion-col [size]=\"2\">\r\n               <ion-label>Start Date</ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col [size]=\"1\"></ion-col>\r\n      \r\n          <ion-col [size]=\"9\">\r\n               <ion-label *ngIf=\"!isEditing && !isAdding\">\r\n                    {{ detailObject?.StartDate | date:\"MM/dd/yyyy\" }}\r\n               </ion-label>\r\n\r\n               <ion-input *ngIf=\"isEditing && !isAdding\" class=\"editAddSelect\" type=\"date\" [(ngModel)]=\"detailObject.StartDate\" [value]=\"detailObject.StartDate\"></ion-input>\r\n          \r\n               <ion-input *ngIf=\"isAdding\" type=\"date\" class=\"editAddSelect\" [(ngModel)]=\"addItemStartDate\" [value]=\"addItemStartDate\"></ion-input>\r\n          </ion-col>\r\n     </ion-row>\r\n\r\n     <ion-row>\r\n          <ion-col [size]=\"2\">\r\n               <ion-label>End Date</ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col [size]=\"1\"></ion-col>\r\n   \r\n          <ion-col [size]=\"9\">\r\n               <ion-label *ngIf=\"!isEditing && !isAdding\">\r\n                    {{ detailObject?.EndDate | date:\"MM/dd/yyyy\" }}\r\n               </ion-label>\r\n\r\n               <ion-input *ngIf=\"isEditing && !isAdding\" class=\"editAddSelect\" type=\"date\" [(ngModel)]=\"detailObject.EndDate\" [value]=\"detailObject.EndDate\"></ion-input>\r\n\r\n               <ion-input *ngIf=\"isAdding\" type=\"date\" class=\"editAddSelect\" [(ngModel)]=\"addItemEndDate\" [value]=\"addItemEndDate\"></ion-input>\r\n          </ion-col>\r\n     </ion-row>\r\n\r\n     <ion-row>\r\n          <ion-col [size]=\"3\">\r\n               <ion-label>Source</ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col [size]=\"9\">\r\n               <ion-label *ngIf=\"!isEditing && !isAdding\">\r\n                    {{ dataService.getSourceName(detailObject?.WatchListSourceID) }}\r\n               </ion-label>\r\n\r\n               <select class=\"editAddSelect\" *ngIf=\"isEditing && !isAdding\" placeholder='Source' name=\"Source\" [(ngModel)]=\"detailObject.WatchListSourceID\">\r\n                    <option *ngFor=\"let currItem of dataService.watchListSources;trackBy: dataService.trackByFn\" [value]=\"currItem.WatchListSourceID\">{{currItem?.WatchListSourceName}}</option>\r\n               </select>\r\n\r\n               <select class=\"editAddSelect\" *ngIf=\"isAdding\" placeholder='Name' name=\"title\" [(ngModel)]=\"addItemSource\">\r\n                    <option *ngFor=\"let currItem of dataService.watchListSources;trackBy: dataService.trackByFn\" [value]=\"currItem?.WatchListSourceID\">{{currItem?.WatchListSourceName}}</option>\r\n               </select>\r\n          </ion-col>\r\n     </ion-row>\r\n\r\n     <ion-row *ngIf=\"(isAdding && addItemID !== '' && dataService.getWatchListTypeNameByWatchListItemID(addItemID) === 'TV') || (!isAdding && detailObject !== null && dataService.getWatchListTypeName(detailObject?.WatchListTypeID) === 'TV')\">\r\n          <ion-col [size]=\"3\">\r\n               <ion-label>Season</ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col [size]=\"9\">\r\n               <ion-label *ngIf=\"!isEditing && !isAdding\">\r\n                    {{ detailObject?.Season }}\r\n               </ion-label>\r\n\r\n               <ion-input *ngIf=\"isEditing && !isAdding\" class=\"editAddSelect shortField\" maxlength=\"3\" type=\"text\" [(ngModel)]=\"detailObject.Season\"></ion-input>\r\n\r\n               <ion-input *ngIf=\"isAdding && !isEditing\" class=\"editAddSelect shortField\" maxlength=\"3\" type=\"text\" [(ngModel)]=\"addSeason\"></ion-input>\r\n          </ion-col>\r\n     </ion-row>\r\n\r\n     <ion-row>\r\n          <ion-col [size]=\"2\">\r\n               <ion-label>Notes</ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col [size]=\"1\"></ion-col>\r\n\r\n          <ion-col [size]=\"9\">\r\n               <ion-label *ngIf=\"!isEditing && !isAdding\">\r\n                    {{ detailObject?.Notes }}\r\n               </ion-label>\r\n\r\n               <ion-input *ngIf=\"isEditing && !isAdding\" class=\"editAddSelect\" type=\"text\" [(ngModel)]=\"detailObject.Notes\"></ion-input>\r\n\r\n               <ion-input *ngIf=\"isAdding && !isEditing\" type=\"text\" class=\"editAddSelect\" [(ngModel)]=\"addItemNotes\"></ion-input>\r\n          </ion-col>\r\n     </ion-row>\r\n\r\n     <ion-row>\r\n          <ion-col [size]=\"3\">\r\n               <ion-label>Rating</ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col *ngIf=\"isAdding\" [size]=\"9\">\r\n               <ion-icon *ngFor=\"let number of numSequence(dataService.ratingMax);let index=index\" (click)=\"ratingClickHandler(index)\" [name]=\"getRatingIcon(index)\"></ion-icon>\r\n          </ion-col>\r\n\r\n          <ion-col *ngIf=\"!isAdding\" [size]=\"9\">\r\n               <ion-icon *ngFor=\"let number of numSequence(dataService.ratingMax);let index=index\" (click)=\"ratingClickHandler(index)\" [name]=\"getRatingIcon(index)\"></ion-icon>\r\n          </ion-col>\r\n     </ion-row>\r\n</ion-grid>\r\n\r\n<ion-icon id=\"deleteIcon\" name=\"trash-outline\" *ngIf=\"!isAdding\" (click)=\"deleteWatchList(currWatchList)\"></ion-icon>";

/***/ }),

/***/ 3038:
/*!***********************************************************************************************!*\
  !*** ./src/app/components/watchlist-items-detail/watchlist-items-detail.page.html?ngResource ***!
  \***********************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-grid>\r\n     <ion-grid>\r\n          <ion-row>\r\n               <ion-col size=\"1\">\r\n                    <ion-icon *ngIf=\"!isAdding && !isEditing\" name=\"create-outline\" (click)=\"editWatchListItem()\"></ion-icon>\r\n                    <ion-icon *ngIf=\"isAdding || isEditing\" name=\"save-outline\" (click)=\"saveWatchListItem()\"></ion-icon>\r\n               </ion-col>\r\n  \r\n               <ion-col size=\"1\"></ion-col>\r\n  \r\n               <ion-col size=\"2\">\r\n                    <ion-icon *ngIf=\"isAdding || isEditing\" name=\"close-circle-outline\" (click)=\"cancelWatchListItem()\"></ion-icon>\r\n               </ion-col>\r\n         \r\n               <ion-col size=\"7\"></ion-col>\r\n  \r\n              <ion-col size=\"1\">\r\n                    <ion-icon  *ngIf=\"!isAdding && !isEditing\" name=\"close-outline\" class=\"cancelButton\" (click)=\"dataService.closeOverlay()\"></ion-icon>\r\n               </ion-col>\r\n          </ion-row>\r\n  \r\n          <ion-row>\r\n               <ion-col [size]=\"12\"></ion-col>\r\n          </ion-row>\r\n     </ion-grid>\r\n\r\n     <a class=\"nooutline\" *ngIf=\"detailObject?.IMDB_URL !== null\" href=\"{{detailObject?.IMDB_URL}}\" target=\"_blank\">\r\n          <img *ngIf=\"detailObject?.IMDB_Poster !== null\" class=\"poster\" src=\"{{detailObject?.IMDB_Poster}}\">\r\n     </a>\r\n\r\n     <img *ngIf=\"detailObject?.IMDB_URL === null && detailObject?.IMDB_Poster !== null\" class=\"poster\" src=\"{{detailObject?.IMDB_Poster}}\">\r\n\r\n     <ion-row *ngIf=\"!isAdding\">\r\n          <ion-col [size]=\"2\">\r\n               <ion-label>Item ID</ion-label>\r\n          </ion-col>\r\n \r\n          <ion-col [size]=\"1\"></ion-col>\r\n \r\n          <ion-col [size]=\"9\">\r\n               <ion-label>\r\n                    {{ detailObject.WatchListItemID }}\r\n               </ion-label>\r\n          </ion-col>\r\n     </ion-row>\r\n\r\n     <ion-row>\r\n          <ion-col [size]=\"12\"></ion-col>\r\n     </ion-row>\r\n\r\n     <ion-row>\r\n          <ion-col [size]=\"2\">\r\n               <ion-label>Name</ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col [size]=\"1\"></ion-col>\r\n         \r\n          <ion-col [size]=\"9\">\r\n               <ion-label *ngIf=\"!isEditing && !isAdding\">\r\n                    {{ detailObject.WatchListItemName }}\r\n               </ion-label>\r\n\r\n               <ion-input *ngIf=\"isEditing\" class=\"editAddSelect\" type=\"text\" [(ngModel)]=\"detailObject.WatchListItemName\" [value]=\"detailObject.WatchListItemName\" ></ion-input>\r\n\r\n               <ion-input *ngIf=\"isAdding\" class=\"editAddSelect\" type=\"text\" [(ngModel)]=\"addItemName\" [value]=\"addItemName\" ></ion-input>\r\n          </ion-col>\r\n     </ion-row>\r\n\r\n     <ion-row>\r\n          <ion-col [size]=\"12\"></ion-col>\r\n     </ion-row>\r\n\r\n     <ion-row>\r\n          <ion-col [size]=\"2\">\r\n               <ion-label>Type</ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col [size]=\"1\"></ion-col>\r\n      \r\n          <ion-col [size]=\"9\">\r\n               <ion-label *ngIf=\"!isEditing && !isAdding\">\r\n                    {{ dataService.getWatchListTypeName(detailObject.WatchListTypeID) }}\r\n               </ion-label>\r\n\r\n               <select class=\"editAddSelect\" *ngIf=\"isEditing\" placeholder='Type' name=\"title\" [(ngModel)]=\"detailObject.WatchListTypeID\">\r\n                    <option *ngFor=\"let currItem of dataService.watchListTypes;trackBy: dataService.trackByFn\" [value]=\"currItem.WatchListTypeID\">{{currItem.WatchListTypeName}}</option>\r\n               </select>\r\n\r\n               <select class=\"editAddSelect\" *ngIf=\"isAdding\" placeholder='Type' name=\"title\" [(ngModel)]=\"addItemType\">\r\n                    <option *ngFor=\"let currItem of dataService.watchListTypes;trackBy: dataService.trackByFn\" [value]=\"currItem.WatchListTypeID\">{{currItem.WatchListTypeName}}</option>\r\n               </select>\r\n          </ion-col>\r\n     </ion-row>\r\n\r\n     <ion-row>\r\n          <ion-col [size]=\"12\"></ion-col>\r\n     </ion-row>\r\n\r\n     <ion-row>\r\n          <ion-col [size]=\"2\">\r\n               <ion-label>IMDB URL</ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col [size]=\"1\"></ion-col>\r\n   \r\n          <ion-col [size]=\"9\">\r\n               <ion-label *ngIf=\"!isEditing && !isAdding\">\r\n                    {{ detailObject.IMDB_URL }}\r\n               </ion-label>\r\n\r\n               <ion-input *ngIf=\"isEditing\" class=\"editAddSelect\" type=\"text\" [(ngModel)]=\"detailObject.IMDB_URL\"></ion-input>\r\n\r\n               <ion-input *ngIf=\"isAdding\" class=\"editAddSelect\" type=\"text\" [(ngModel)]=\"addItemIMDBURL\"></ion-input>\r\n          </ion-col>\r\n     </ion-row>\r\n\r\n     <ion-row>\r\n          <ion-col [size]=\"2\">\r\n               <ion-label>Image</ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col [size]=\"1\"></ion-col>\r\n   \r\n          <ion-col [size]=\"9\">\r\n               <ion-label *ngIf=\"!isAdding && !isEditing\">{{detailObject.IMDB_Poster}}</ion-label>\r\n               <ion-input *ngIf=\"isEditing\" class=\"editAddSelect\" type=\"text\" [(ngModel)]=\"detailObject.IMDB_Poster\"></ion-input>\r\n\r\n               <ion-input *ngIf=\"isAdding\" class=\"editAddSelect\" type=\"text\" [(ngModel)]=\"addItemIMDBPoster\"></ion-input>\r\n          </ion-col>\r\n     </ion-row>\r\n\r\n     <ion-row>\r\n          <ion-col [size]=\"12\"></ion-col>\r\n     </ion-row>\r\n\r\n     <ion-row>\r\n          <ion-col [size]=\"2\">\r\n               <ion-label>Notes</ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col [size]=\"1\"></ion-col>\r\n\r\n          <ion-col [size]=\"9\">\r\n               <ion-label *ngIf=\"!isEditing && !isAdding\">\r\n                    {{ detailObject.ItemNotes }}\r\n               </ion-label>\r\n\r\n               <ion-input *ngIf=\"isEditing && !isAdding\" class=\"editAddSelect\" type=\"text\" [(ngModel)]=\"detailObject.ItemNotes\"></ion-input>\r\n\r\n               <ion-input *ngIf=\"isAdding\" type=\"text\" class=\"editAddSelect\" [(ngModel)]=\"addItemNotes\"></ion-input>\r\n          </ion-col>\r\n     </ion-row>\r\n</ion-grid>\r\n\r\n<ion-icon id=\"deleteIcon\" name=\"trash-outline\" *ngIf=\"!isAdding\" (click)=\"deleteWatchListItem(currWatchListItem)\"></ion-icon>";

/***/ }),

/***/ 2764:
/*!***********************************************************************************************!*\
  !*** ./src/app/components/watchlist-queue-detail/watchlist-queue-detail.page.html?ngResource ***!
  \***********************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-grid>\r\n     <ion-grid>\r\n          <ion-row>\r\n               <ion-col size=\"1\">\r\n                    <ion-icon *ngIf=\"!isAdding && !isEditing\" name=\"create-outline\" (click)=\"editWatchListQueueItem()\"></ion-icon>\r\n                    <ion-icon *ngIf=\"isAdding || isEditing\" name=\"save-outline\" (click)=\"saveWatchListQueueItem()\"></ion-icon>\r\n               </ion-col>\r\n\r\n               <ion-col size=\"1\"></ion-col>\r\n\r\n               <ion-col size=\"2\">\r\n                    <ion-icon *ngIf=\"isAdding || isEditing\" name=\"close-circle-outline\" (click)=\"cancelWatchListQueueItem()\"></ion-icon>\r\n               </ion-col>\r\n\r\n               <ion-col size=\"7\"></ion-col>\r\n\r\n               <ion-col size=\"1\">\r\n                    <ion-icon  *ngIf=\"!isAdding && !isEditing\" name=\"close-outline\" class=\"cancelButton\" (click)=\"dataService.closeOverlay()\"></ion-icon>\r\n               </ion-col>\r\n          </ion-row>\r\n\r\n          <ion-row>\r\n               <ion-col [size]=\"12\"></ion-col>\r\n          </ion-row>\r\n     </ion-grid>\r\n\r\n     <a class=\"nooutline\" *ngIf=\"detailObject?.IMDB_URL !== null\" href=\"{{detailObject?.IMDB_URL}}\" target=\"_blank\">\r\n          <img *ngIf=\"detailObject?.IMDB_Poster !== null\" class=\"poster\" src=\"{{detailObject?.IMDB_Poster}}\">\r\n     </a>\r\n\r\n     <img *ngIf=\"detailObject?.IMDB_URL === null && detailObject?.IMDB_Poster !== null\" class=\"poster\" src=\"{{detailObject?.IMDB_Poster}}\">\r\n\r\n     <ion-row>\r\n          <ion-col [size]=\"2\">\r\n               <ion-label>Queue ID</ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col [size]=\"1\"></ion-col>\r\n\r\n          <ion-col [size]=\"9\">\r\n               <ion-label *ngIf=\"!isAdding\">\r\n                    {{ detailObject.WatchListQueueItemID }}\r\n               </ion-label>\r\n          </ion-col>\r\n     </ion-row>\r\n\r\n     <ion-row>\r\n          <ion-col [size]=\"12\"></ion-col>\r\n     </ion-row>\r\n\r\n     <ion-row>\r\n          <ion-col [size]=\"2\">\r\n               <ion-label>Name</ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col [size]=\"1\"></ion-col>\r\n\r\n          <ion-col [size]=\"9\">\r\n               <ion-label *ngIf=\"!isEditing && !isAdding\">{{ dataService.getWatchListItemName(detailObject.WatchListItemID) }}</ion-label>\r\n\r\n               <select class=\"editAddSelect\" *ngIf=\"isEditing\" placeholder='Name' name=\"title\" type=\"number\" [(ngModel)]=\"detailObject.WatchListItemID\">\r\n                    <option *ngFor=\"let currItem of dataService.watchListNames;trackBy: dataService.trackByFn\" [value]=\"currItem.WatchListItemID\">{{currItem.WatchListItemName}}</option>\r\n               </select>\r\n\r\n               <select class=\"editAddSelect\" *ngIf=\"isAdding\" placeholder='Name' name=\"title\" type=\"number\" [(ngModel)]=\"addQueueItemID\">\r\n                    <option *ngFor=\"let currItem of dataService.watchListNames;trackBy: dataService.trackByFn\" [value]=\"currItem.WatchListItemID\">{{currItem.WatchListItemName}}</option>\r\n               </select>\r\n          </ion-col>\r\n     </ion-row>\r\n\r\n     <ion-row>\r\n          <ion-col [size]=\"12\" *ngIf=\"!isEditing && !isAdding\"></ion-col>\r\n     </ion-row>\r\n\r\n     <ion-row *ngIf=\"!isAdding\">\r\n          <ion-col [size]=\"2\">\r\n               <ion-label>Type</ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col [size]=\"1\"></ion-col>\r\n\r\n          <ion-col [size]=\"9\">\r\n               <ion-label>{{ dataService.getWatchListTypeName(detailObject.WatchListTypeID) }}</ion-label>\r\n          </ion-col>\r\n     </ion-row>\r\n\r\n     <ion-row>\r\n          <ion-col [size]=\"12\"></ion-col>\r\n     </ion-row>\r\n\r\n     <ion-row>\r\n          <ion-col [size]=\"2\">\r\n               <ion-label>Notes</ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col [size]=\"1\"></ion-col>\r\n\r\n          <ion-col [size]=\"9\">\r\n               <ion-label *ngIf=\"!isEditing && !isAdding\">{{ detailObject.Notes }}</ion-label>\r\n\r\n               <ion-input *ngIf=\"isEditing\" class=\"editAddSelect\" type=\"text\" [(ngModel)]=\"detailObject.Notes\"></ion-input>\r\n\r\n               <ion-input *ngIf=\"isAdding\" class=\"editAddSelect\" type=\"text\" [(ngModel)]=\"addItemNotes\"></ion-input>\r\n          </ion-col>\r\n     </ion-row>\r\n</ion-grid>\r\n\r\n<ion-icon id=\"deleteIcon\" name=\"trash-outline\" *ngIf=\"!isAdding\" (click)=\"deleteWatchListItem(currWatchListItem)\"></ion-icon>";

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(4431)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map