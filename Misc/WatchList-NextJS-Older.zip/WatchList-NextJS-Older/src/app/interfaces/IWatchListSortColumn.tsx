export default interface IWatchListSortColumn {
     key: string,
     value: string
}