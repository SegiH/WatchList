export default interface WatchListSource {
     WatchListSourceID: number,
     WatchListSourceName: string
}