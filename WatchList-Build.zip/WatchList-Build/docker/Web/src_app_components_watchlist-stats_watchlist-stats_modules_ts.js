"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_components_watchlist-stats_watchlist-stats_modules_ts"],{

/***/ 2755:
/*!******************************************************************************!*\
  !*** ./src/app/components/watchlist-stats/watchlist-stats-routing.module.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WatchListStatsPageRoutingModule": () => (/* binding */ WatchListStatsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _watchlist_stats_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlist-stats.page */ 4352);




const routes = [
    {
        path: '',
        component: _watchlist_stats_page__WEBPACK_IMPORTED_MODULE_0__.WatchListStatsComponent,
    }
];
let WatchListStatsPageRoutingModule = class WatchListStatsPageRoutingModule {
};
WatchListStatsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], WatchListStatsPageRoutingModule);



/***/ }),

/***/ 4498:
/*!***********************************************************************!*\
  !*** ./src/app/components/watchlist-stats/watchlist-stats.modules.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WatchListStatsPageModule": () => (/* binding */ WatchListStatsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _watchlist_stats_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlist-stats.page */ 4352);
/* harmony import */ var _watchlist_stats_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./watchlist-stats-routing.module */ 2755);







let WatchListStatsPageModule = class WatchListStatsPageModule {
    constructor() { }
    handleError(response, error) { }
};
WatchListStatsPageModule.ctorParameters = () => [];
WatchListStatsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _watchlist_stats_routing_module__WEBPACK_IMPORTED_MODULE_1__.WatchListStatsPageRoutingModule
        ],
        declarations: [_watchlist_stats_page__WEBPACK_IMPORTED_MODULE_0__.WatchListStatsComponent]
    })
], WatchListStatsPageModule);



/***/ }),

/***/ 4352:
/*!********************************************************************!*\
  !*** ./src/app/components/watchlist-stats/watchlist-stats.page.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WatchListStatsComponent": () => (/* binding */ WatchListStatsComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _watchlist_stats_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlist-stats.page.html?ngResource */ 7255);
/* harmony import */ var _watchlist_stats_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./watchlist-stats.page.scss?ngResource */ 1468);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _core_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../core/data.service */ 3943);





let WatchListStatsComponent = class WatchListStatsComponent {
    constructor(dataService) {
        this.dataService = dataService;
    }
    ngOnInit() {
        this.getWatchListMovieStatsSubscription();
        this.getWatchListTVStatsSubscription();
        this.getWatchListSourceStatsSubscription();
        this.getWatchListTopRatedStatsSubscription();
    }
    getWatchListMovieStatsSubscription() {
        this.dataService.getWatchListMovieStats().subscribe((response) => {
            this.watchListMovieStats = response;
        }, error => {
            this.dataService.handleError(error);
        });
    }
    getWatchListSourceStatsSubscription() {
        this.dataService.getWatchListSourceStats().subscribe((response) => {
            this.watchListSourceStats = response;
        }, error => {
            this.dataService.handleError(error);
        });
    }
    getWatchListTopRatedStatsSubscription() {
        this.dataService.getWatchListTopRatedStats().subscribe((response) => {
            this.watchListTopRatedStats = response;
        }, error => {
            this.dataService.handleError(error);
        });
    }
    getWatchListTVStatsSubscription() {
        this.dataService.getWatchListTVStats().subscribe((response) => {
            this.watchListTVStats = response;
        }, error => {
            this.dataService.handleError(error);
        });
    }
};
WatchListStatsComponent.ctorParameters = () => [
    { type: _core_data_service__WEBPACK_IMPORTED_MODULE_2__.DataService }
];
WatchListStatsComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-watchlist',
        template: _watchlist_stats_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_watchlist_stats_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], WatchListStatsComponent);



/***/ }),

/***/ 1468:
/*!*********************************************************************************!*\
  !*** ./src/app/components/watchlist-stats/watchlist-stats.page.scss?ngResource ***!
  \*********************************************************************************/
/***/ ((module) => {

module.exports = "ion-content {\n  overflow: visible;\n}\n\n.ion-list-parent {\n  width: 100%;\n  overflow: auto;\n}\n\nion-card {\n  display: flex;\n  width: 100%;\n}\n\nion-content {\n  overflow: auto;\n}\n\nion-list.md.list-md {\n  min-width: 1000px;\n  overflow: scroll;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndhdGNobGlzdC1zdGF0cy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxpQkFBQTtBQUNKOztBQUVBO0VBQ0ksV0FBQTtFQUNBLGNBQUE7QUFDSjs7QUFFQTtFQUNJLGFBQUE7RUFDQSxXQUFBO0FBQ0o7O0FBRUE7RUFDSSxjQUFBO0FBQ0o7O0FBRUE7RUFDSSxpQkFBQTtFQUNBLGdCQUFBO0FBQ0oiLCJmaWxlIjoid2F0Y2hsaXN0LXN0YXRzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50IHtcclxuICAgIG92ZXJmbG93OiB2aXNpYmxlO1xyXG59XHJcblxyXG4uaW9uLWxpc3QtcGFyZW50IHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgb3ZlcmZsb3c6IGF1dG87XHJcbn1cclxuXHJcbmlvbi1jYXJkIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICB3aWR0aDogMTAwJTtcclxufVxyXG5cclxuaW9uLWNvbnRlbnQge1xyXG4gICAgb3ZlcmZsb3c6IGF1dG87XHJcbn1cclxuXHJcbmlvbi1saXN0Lm1kLmxpc3QtbWQge1xyXG4gICAgbWluLXdpZHRoOiAxMDAwcHg7XHJcbiAgICBvdmVyZmxvdzogc2Nyb2xsO1xyXG59XHJcbiJdfQ== */";

/***/ }),

/***/ 7255:
/*!*********************************************************************************!*\
  !*** ./src/app/components/watchlist-stats/watchlist-stats.page.html?ngResource ***!
  \*********************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header [translucent]=\"true\">\r\n     <ion-toolbar>\r\n          <ion-buttons slot=\"start\"> \r\n               <ion-menu-button></ion-menu-button>                \r\n          </ion-buttons>\r\n          \r\n          <ion-title>WatchList Items</ion-title>\r\n     </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content *ngIf=\"dataService.isBackendURLSet() && dataService.isLoggedIn\">\r\n     <ion-refresher slot=\"fixed\" (ionRefresh)=\"dataService.pullToRefresh($event,'WatchListItems')\">\r\n          <ion-refresher-content></ion-refresher-content>\r\n     </ion-refresher>\r\n     \r\n     <ion-accordion-group expand=\"inset\">\r\n          <ion-accordion value=\"first\">\r\n               <ion-item slot=\"header\" color=\"light\">\r\n                    <ion-label>Most frequently watched Source</ion-label>\r\n               </ion-item>\r\n\r\n               <h2>Most frequently watched Source</h2>\r\n\r\n               <ion-list class=\"ion-list-parent\" *ngFor=\"let currentSource of watchListSourceStats\" slot=\"content\">\r\n                    <ion-item>\r\n                         <ion-grid>\r\n                              <ion-row>\r\n                                   <ion-col size=\"6\" class=\"first\">\r\n                                        <ion-label>{{ currentSource['WatchListSourceName'] }} watched {{ currentSource['SourceCount'] }} time(s)</ion-label>\r\n                                   </ion-col>\r\n                              </ion-row>\r\n                         </ion-grid>\r\n                    </ion-item>\r\n               </ion-list>\r\n          </ion-accordion>\r\n\r\n          <ion-accordion value=\"second\">\r\n               <ion-item slot=\"header\" color=\"light\">\r\n                    <ion-label>Top Rated</ion-label>\r\n               </ion-item>\r\n\r\n               <h2>Top Rated</h2>\r\n\r\n               <ion-list class=\"ion-list-parent\" *ngFor=\"let currentTopRated of watchListTopRatedStats\" slot=\"content\">\r\n                    <ion-item>\r\n                         <ion-grid>\r\n                              <ion-row>\r\n                                   <ion-col size=\"12\" class=\"first\">\r\n                                        <ion-label>{{ currentTopRated['WatchListItemName'] }} {{ (currentTopRated['Season'] !== null ? \": Season \" + currentTopRated['Season'] : \"\") }}</ion-label>\r\n                                   </ion-col>\r\n\r\n                                   <ion-col size=\"12\" class=\"first\">\r\n                                        <ion-label>{{ currentTopRated['Rating'] }} / {{ dataService.ratingMax }}</ion-label>\r\n                                   </ion-col>\r\n                              </ion-row>\r\n                         </ion-grid>\r\n                    </ion-item>\r\n               </ion-list>\r\n          </ion-accordion>\r\n\r\n          <ion-accordion value=\"third\">\r\n               <ion-item slot=\"header\" color=\"light\">\r\n                    <ion-label>Top 10 Movies</ion-label>\r\n               </ion-item>\r\n\r\n               <ion-list *ngFor=\"let currentMovie of watchListMovieStats\" slot=\"content\">\r\n                    <ion-item>\r\n                         <ion-grid>\r\n                              <ion-row>\r\n                                   <ion-col size=\"12\" class=\"first\">\r\n                                        <ion-label *ngIf=\"currentMovie['IMDB_URL'] === null\">\"{{ currentMovie['WatchListItemName'] }}\"</ion-label>\r\n                                        <a *ngIf=\"currentMovie['IMDB_URL'] !== null\" [href]=\"currentMovie['IMDB_URL']\" target=\"_blank\">{{ currentMovie['WatchListItemName'] }}</a>&nbsp;\r\n                                   </ion-col>\r\n\r\n                                   <ion-col size=\"12\" class=\"second\">\r\n                                        <ion-label>watched {{ currentMovie['ItemCount'] }} time(s)</ion-label>\r\n                                   </ion-col>\r\n                              </ion-row>\r\n                         </ion-grid>\r\n                    </ion-item>\r\n               </ion-list>\r\n          </ion-accordion>\r\n\r\n          <ion-accordion value=\"fourth\">\r\n               <ion-item slot=\"header\" color=\"light\">\r\n                 <ion-label>Top 10 TV Shows</ion-label>\r\n               </ion-item>\r\n\r\n               <div slot=\"content\">\r\n                    <ion-list *ngFor=\"let currentShow of watchListTVStats\">\r\n                         <ion-item>\r\n                              <ion-grid>\r\n                                   <ion-row>\r\n                                        <ion-col size=\"12\">\r\n                                             <ion-label *ngIf=\"currentShow['IMDB_URL'] === null\">{{ currentShow['WatchListItemName'] }} watched {{ currentShow['ItemCount'] }} times</ion-label>\r\n\r\n                                             <ion-label>\r\n                                                  <a *ngIf=\"currentShow['IMDB_URL'] !== null\" [href]=\"currentShow['IMDB_URL']\" target=\"_blank\">{{ currentShow['WatchListItemName'] }}</a>  watched {{ currentShow['ItemCount'] }} times\r\n                                             </ion-label>\r\n                                        </ion-col>\r\n\r\n                                        <ion-col size=\"12\">\r\n                                             <ion-label>{{ currentShow['StartDate'] | date: 'MM/dd/yyyy' }} thru {{ currentShow['EndDate'] | date: 'MM/dd/yyyy' }}</ion-label>\r\n                                        </ion-col>\r\n                                   </ion-row>\r\n                              </ion-grid>\r\n                         </ion-item>\r\n                    </ion-list>\r\n               </div>\r\n          </ion-accordion>\r\n     </ion-accordion-group>\r\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_components_watchlist-stats_watchlist-stats_modules_ts.js.map