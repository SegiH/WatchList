export default interface IWatchListTVStat {
     UserID: number,
     WatchListItemName: string
     StartDate: string
     EndDate: string
     ItemCount: number,
     IMDB_URL: string
}