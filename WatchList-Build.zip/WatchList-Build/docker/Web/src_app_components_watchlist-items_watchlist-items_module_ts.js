"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_components_watchlist-items_watchlist-items_module_ts"],{

/***/ 4975:
/*!******************************************************************************!*\
  !*** ./src/app/components/watchlist-items/watchlist-items-routing.module.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WatchListItemsPageRoutingModule": () => (/* binding */ WatchListItemsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _watchlist_items_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlist-items.page */ 2905);




const routes = [
    {
        path: '',
        component: _watchlist_items_page__WEBPACK_IMPORTED_MODULE_0__.WatchListItemsComponent,
    }
];
let WatchListItemsPageRoutingModule = class WatchListItemsPageRoutingModule {
};
WatchListItemsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], WatchListItemsPageRoutingModule);



/***/ }),

/***/ 4078:
/*!**********************************************************************!*\
  !*** ./src/app/components/watchlist-items/watchlist-items.module.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WatchListItemsPageModule": () => (/* binding */ WatchListItemsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _watchlist_items_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlist-items.page */ 2905);
/* harmony import */ var _watchlist_items_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./watchlist-items-routing.module */ 4975);







let WatchListItemsPageModule = class WatchListItemsPageModule {
};
WatchListItemsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _watchlist_items_routing_module__WEBPACK_IMPORTED_MODULE_1__.WatchListItemsPageRoutingModule
        ],
        declarations: [_watchlist_items_page__WEBPACK_IMPORTED_MODULE_0__.WatchListItemsComponent]
    })
], WatchListItemsPageModule);



/***/ }),

/***/ 2905:
/*!********************************************************************!*\
  !*** ./src/app/components/watchlist-items/watchlist-items.page.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WatchListItemsComponent": () => (/* binding */ WatchListItemsComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _watchlist_items_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlist-items.page.html?ngResource */ 504);
/* harmony import */ var _watchlist_items_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./watchlist-items.page.scss?ngResource */ 1411);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _core_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../core/data.service */ 3943);





let WatchListItemsComponent = class WatchListItemsComponent {
    constructor(dataService) {
        this.dataService = dataService;
        this.currentPage = 1;
        this.math = Math;
    }
    ngDoCheck() {
        if (this.dataService.imdb_url_missing === null) {
            this.dataService.imdb_url_missing = false;
        }
        if (typeof this.dataService.watchListItems !== 'undefined' && this.dataService.watchListItems.length > 0) {
            this.filteredWatchListItems = this.dataService.watchListItems.filter((wli) => {
                return ((this.dataService.searchTerm === ""
                    || (this.dataService.searchTerm !== ""
                        && (this.dataService.getWatchListItemName(wli.WatchListItemID).toLowerCase().includes(this.dataService.searchTerm.toLowerCase())
                            || (wli.WatchListTypeID !== null && this.dataService.getWatchListTypeName(wli.WatchListTypeID).toLowerCase().includes(this.dataService.searchTerm.toLowerCase()))
                            || (wli.ItemNotes !== null && wli.ItemNotes.toLowerCase().includes(this.dataService.searchTerm.toLowerCase())))))
                    && ((this.dataService.imdb_url_missing === false)));
            });
        }
    }
    addWatchListItem() {
        this.dataService.openDetailOverlay('watchlist-items', null);
    }
    isShown(pageIndex) {
        if (this.filteredWatchListItems.length < this.dataService.itemsPerPage)
            return true;
        if (pageIndex >= ((this.currentPage - 1) * this.dataService.itemsPerPage) && pageIndex < ((this.currentPage - 1) * this.dataService.itemsPerPage) + this.dataService.itemsPerPage)
            return true;
        return false;
    }
    numSequence(n) {
        if (isNaN(n)) {
            alert(`${n} is not valid`);
            return;
        }
        return Array(n);
    }
    paginationClickHandler(relativePage, absolutePage) {
        if (relativePage === -1 || relativePage === 1)
            this.currentPage += relativePage;
        else if (absolutePage)
            this.currentPage = absolutePage;
    }
};
WatchListItemsComponent.ctorParameters = () => [
    { type: _core_data_service__WEBPACK_IMPORTED_MODULE_2__.DataService }
];
WatchListItemsComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-watchlist-items',
        template: _watchlist_items_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_watchlist_items_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], WatchListItemsComponent);



/***/ }),

/***/ 1411:
/*!*********************************************************************************!*\
  !*** ./src/app/components/watchlist-items/watchlist-items.page.scss?ngResource ***!
  \*********************************************************************************/
/***/ ((module) => {

module.exports = ".actionColumn {\n  display: inline-flex;\n}\n\n.detailLink {\n  cursor: pointer;\n  text-decoration: underline;\n}\n\n.IDColumn, .nameColumn {\n  margin-top: 8px;\n}\n\n.ion-list-parent {\n  width: 100%;\n  height: 100%;\n  overflow: auto;\n}\n\n.item-inner {\n  border-style: hidden;\n}\n\n.nomargin {\n  margin-left: 0px;\n  margin-right: 0px;\n}\n\n.page {\n  cursor: pointer;\n  padding-left: 5px;\n  padding-right: 5px;\n  border: 1px solid #ddd;\n  color: black;\n  float: left;\n  padding: 8px 16px;\n  text-decoration: none;\n  overflow-x: visible;\n  height: 40px;\n  vertical-align: middle;\n}\n\n.page:first-child {\n  border-top-left-radius: 5px;\n  border-bottom-left-radius: 5px;\n}\n\n.page:last-child {\n  border-top-right-radius: 5px;\n  border-bottom-right-radius: 5px;\n}\n\n.page.active {\n  background-color: #4285f4;\n  color: white;\n}\n\n.pageSelect {\n  width: 65px;\n}\n\n.pageSpan {\n  display: flex;\n  overflow: auto;\n  width: -moz-fit-content;\n  width: fit-content;\n  border-style: dashed;\n  border-width: 1px;\n}\n\n.pointer {\n  cursor: pointer;\n}\n\n.poster {\n  cursor: pointer;\n  max-height: 125px;\n  max-width: 87px;\n}\n\n.poster:hover {\n  max-height: 250px;\n}\n\nspan > .page:first-child {\n  border-top-left-radius: 5px;\n  border-bottom-left-radius: 5px;\n}\n\nspan > .page:last-child {\n  border-top-right-radius: 5px;\n  border-bottom-right-radius: 5px;\n}\n\nion-card {\n  display: flex;\n  width: 100%;\n}\n\nion-content {\n  overflow: auto;\n}\n\nion-grid > ion-row > ion-col > ion-icon.IDArrowIcon,\nion-grid > ion-row > ion-col > ion-icon.NameArrowIcon,\nion-grid > ion-row > ion-col > ion-icon.TypeArrowIcon,\nion-grid > ion-row > ion-col > ion-icon.IMDBURLArrowIcon {\n  width: 30px;\n  position: relative;\n  vertical-align: bottom;\n}\n\nion-grid > ion-row > ion-col > ion-icon.active {\n  color: #30A199;\n}\n\nion-icon {\n  width: 45px;\n  height: 45px;\n  cursor: pointer;\n}\n\nion-icon.header {\n  vertical-align: middle !important;\n}\n\nion-item > ion-grid > ion-row > ion-col > ion-label {\n  word-break: break-all;\n  overflow-wrap: break-word;\n  word-wrap: break-word;\n  -webkit-hyphens: auto;\n          hyphens: auto;\n  overflow: auto;\n}\n\nion-label {\n  margin-top: 10px;\n}\n\nion-label.header {\n  display: inline;\n}\n\nion-list.md.list-md {\n  min-width: 1000px;\n  overflow: auto;\n}\n\nion-list ion-item ion-grid {\n  background-color: #F1EBE4;\n  border-style: dashed;\n  border-width: 1px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndhdGNobGlzdC1pdGVtcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSyxvQkFBQTtBQUNMOztBQUVBO0VBQ0ssZUFBQTtFQUNBLDBCQUFBO0FBQ0w7O0FBRUE7RUFDSyxlQUFBO0FBQ0w7O0FBRUE7RUFDSyxXQUFBO0VBQ0EsWUFBQTtFQUNBLGNBQUE7QUFDTDs7QUFFQTtFQUNLLG9CQUFBO0FBQ0w7O0FBRUE7RUFDSyxnQkFBQTtFQUNBLGlCQUFBO0FBQ0w7O0FBRUE7RUFDSyxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtFQUNBLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0Esc0JBQUE7QUFDTDs7QUFFQTtFQUNLLDJCQUFBO0VBQ0EsOEJBQUE7QUFDTDs7QUFFQTtFQUNLLDRCQUFBO0VBQ0EsK0JBQUE7QUFDTDs7QUFFQTtFQUNJLHlCQUFBO0VBQ0EsWUFBQTtBQUNKOztBQUVBO0VBQ0ssV0FBQTtBQUNMOztBQUVBO0VBQ0ssYUFBQTtFQUNBLGNBQUE7RUFDQSx1QkFBQTtFQUFBLGtCQUFBO0VBQ0Esb0JBQUE7RUFDQSxpQkFBQTtBQUNMOztBQUVBO0VBQ0ssZUFBQTtBQUNMOztBQUVBO0VBQ0ssZUFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtBQUNMOztBQUVBO0VBQ0ssaUJBQUE7QUFDTDs7QUFFQTtFQUNLLDJCQUFBO0VBQ0EsOEJBQUE7QUFDTDs7QUFFQTtFQUNLLDRCQUFBO0VBQ0EsK0JBQUE7QUFDTDs7QUFFQTtFQUNLLGFBQUE7RUFDQSxXQUFBO0FBQ0w7O0FBRUE7RUFDSyxjQUFBO0FBQ0w7O0FBRUE7Ozs7RUFJSyxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxzQkFBQTtBQUNMOztBQUVBO0VBQ0ssY0FBQTtBQUNMOztBQUVBO0VBQ0ssV0FBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0FBQ0w7O0FBRUE7RUFDSyxpQ0FBQTtBQUNMOztBQUVBO0VBQ0sscUJBQUE7RUFDQSx5QkFBQTtFQUNBLHFCQUFBO0VBQ0EscUJBQUE7VUFBQSxhQUFBO0VBQ0EsY0FBQTtBQUNMOztBQUVBO0VBQ0ssZ0JBQUE7QUFDTDs7QUFFQTtFQUNLLGVBQUE7QUFDTDs7QUFFQTtFQUNLLGlCQUFBO0VBQ0EsY0FBQTtBQUNMOztBQUVBO0VBQ0sseUJBQUE7RUFDQSxvQkFBQTtFQUNBLGlCQUFBO0FBQ0wiLCJmaWxlIjoid2F0Y2hsaXN0LWl0ZW1zLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5hY3Rpb25Db2x1bW4ge1xyXG4gICAgIGRpc3BsYXk6IGlubGluZS1mbGV4O1xyXG59XHJcblxyXG4uZGV0YWlsTGluayB7XHJcbiAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xyXG59XHJcblxyXG4uSURDb2x1bW4sIC5uYW1lQ29sdW1uIHtcclxuICAgICBtYXJnaW4tdG9wOiA4cHg7XHJcbn1cclxuXHJcbi5pb24tbGlzdC1wYXJlbnQge1xyXG4gICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgIGhlaWdodDogMTAwJTtcclxuICAgICBvdmVyZmxvdzogYXV0bztcclxufVxyXG5cclxuLml0ZW0taW5uZXIge1xyXG4gICAgIGJvcmRlci1zdHlsZTogaGlkZGVuO1xyXG59XHJcblxyXG4ubm9tYXJnaW4ge1xyXG4gICAgIG1hcmdpbi1sZWZ0OiAwcHg7XHJcbiAgICAgbWFyZ2luLXJpZ2h0OiAwcHg7XHJcbn1cclxuXHJcbi5wYWdlIHtcclxuICAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICAgcGFkZGluZy1sZWZ0OiA1cHg7XHJcbiAgICAgcGFkZGluZy1yaWdodDogNXB4O1xyXG4gICAgIGJvcmRlcjogMXB4IHNvbGlkICNkZGQ7XHJcbiAgICAgY29sb3I6IGJsYWNrO1xyXG4gICAgIGZsb2F0OiBsZWZ0O1xyXG4gICAgIHBhZGRpbmc6IDhweCAxNnB4O1xyXG4gICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICAgICBvdmVyZmxvdy14OiB2aXNpYmxlO1xyXG4gICAgIGhlaWdodDogNDBweDtcclxuICAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xyXG59XHJcblxyXG4ucGFnZTpmaXJzdC1jaGlsZCB7XHJcbiAgICAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogNXB4O1xyXG4gICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDVweDtcclxuICAgfVxyXG4gICBcclxuLnBhZ2U6bGFzdC1jaGlsZCB7XHJcbiAgICAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDVweDtcclxuICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogNXB4O1xyXG59XHJcblxyXG4ucGFnZS5hY3RpdmUge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzQyODVmNDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxufVxyXG5cclxuLnBhZ2VTZWxlY3Qge1xyXG4gICAgIHdpZHRoOiA2NXB4O1xyXG59XHJcblxyXG4ucGFnZVNwYW4ge1xyXG4gICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgb3ZlcmZsb3c6IGF1dG87XHJcbiAgICAgd2lkdGg6IGZpdC1jb250ZW50O1xyXG4gICAgIGJvcmRlci1zdHlsZTogZGFzaGVkO1xyXG4gICAgIGJvcmRlci13aWR0aDogMXB4O1xyXG59XHJcblxyXG4ucG9pbnRlciB7XHJcbiAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcblxyXG4ucG9zdGVyIHtcclxuICAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICAgbWF4LWhlaWdodDogMTI1cHg7XHJcbiAgICAgbWF4LXdpZHRoOiA4N3B4O1xyXG59XHJcblxyXG4ucG9zdGVyOmhvdmVyIHtcclxuICAgICBtYXgtaGVpZ2h0OiAyNTBweDtcclxufVxyXG5cclxuc3BhbiA+IC5wYWdlOmZpcnN0LWNoaWxkIHtcclxuICAgICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiA1cHg7XHJcbiAgICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogNXB4O1xyXG59XHJcblxyXG5zcGFuID4gLnBhZ2U6bGFzdC1jaGlsZCB7XHJcbiAgICAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDVweDtcclxuICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogNXB4O1xyXG59XHJcblxyXG5pb24tY2FyZCB7XHJcbiAgICAgZGlzcGxheTogZmxleDtcclxuICAgICB3aWR0aDogMTAwJTtcclxufVxyXG5cclxuaW9uLWNvbnRlbnQge1xyXG4gICAgIG92ZXJmbG93OiBhdXRvO1xyXG59XHJcblxyXG5pb24tZ3JpZCA+IGlvbi1yb3cgPiBpb24tY29sID4gaW9uLWljb24uSURBcnJvd0ljb24sIFxyXG5pb24tZ3JpZCA+IGlvbi1yb3cgPiBpb24tY29sID4gaW9uLWljb24uTmFtZUFycm93SWNvbixcclxuaW9uLWdyaWQgPiBpb24tcm93ID4gaW9uLWNvbCA+IGlvbi1pY29uLlR5cGVBcnJvd0ljb24sXHJcbmlvbi1ncmlkID4gaW9uLXJvdyA+IGlvbi1jb2wgPiBpb24taWNvbi5JTURCVVJMQXJyb3dJY29uIHtcclxuICAgICB3aWR0aDogMzBweDtcclxuICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgdmVydGljYWwtYWxpZ246IGJvdHRvbTtcclxufVxyXG5cclxuaW9uLWdyaWQgPiBpb24tcm93ID4gaW9uLWNvbCA+IGlvbi1pY29uLmFjdGl2ZSB7XHJcbiAgICAgY29sb3I6ICMzMEExOTk7XHJcbn1cclxuXHJcbmlvbi1pY29uIHtcclxuICAgICB3aWR0aDogNDVweDtcclxuICAgICBoZWlnaHQ6IDQ1cHg7XHJcbiAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcblxyXG5pb24taWNvbi5oZWFkZXIge1xyXG4gICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGUgIWltcG9ydGFudDtcclxufVxyXG5cclxuaW9uLWl0ZW0gPiBpb24tZ3JpZCA+IGlvbi1yb3cgPiBpb24tY29sID4gaW9uLWxhYmVsIHtcclxuICAgICB3b3JkLWJyZWFrOiBicmVhay1hbGw7XHJcbiAgICAgb3ZlcmZsb3ctd3JhcDogYnJlYWstd29yZDtcclxuICAgICB3b3JkLXdyYXA6IGJyZWFrLXdvcmQ7XHJcbiAgICAgaHlwaGVuczogYXV0bztcclxuICAgICBvdmVyZmxvdzogYXV0bztcclxufVxyXG5cclxuaW9uLWxhYmVsIHtcclxuICAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG59XHJcblxyXG5pb24tbGFiZWwuaGVhZGVyIHtcclxuICAgICBkaXNwbGF5OiBpbmxpbmU7XHJcbn1cclxuXHJcbmlvbi1saXN0Lm1kLmxpc3QtbWQge1xyXG4gICAgIG1pbi13aWR0aDogMTAwMHB4O1xyXG4gICAgIG92ZXJmbG93OiBhdXRvO1xyXG59XHJcblxyXG5pb24tbGlzdCBpb24taXRlbSBpb24tZ3JpZCB7XHJcbiAgICAgYmFja2dyb3VuZC1jb2xvcjogI0YxRUJFNDtcclxuICAgICBib3JkZXItc3R5bGU6IGRhc2hlZDtcclxuICAgICBib3JkZXItd2lkdGg6IDFweDtcclxufSJdfQ== */";

/***/ }),

/***/ 504:
/*!*********************************************************************************!*\
  !*** ./src/app/components/watchlist-items/watchlist-items.page.html?ngResource ***!
  \*********************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header [translucent]=\"true\">\r\n     <ion-toolbar>\r\n          <ion-buttons slot=\"start\"> \r\n               <ion-menu-button></ion-menu-button>                \r\n          </ion-buttons>\r\n          \r\n          <ion-grid>\r\n               <ion-row>\r\n                    <ion-col size=\"12\">\r\n                         <ion-searchbar *ngIf=\"dataService.isBackendURLSet() && dataService.isLoggedIn\"(ionChange)=\"dataService.searchTermChangeHandler($event)\" [disabled]=\"dataService.isAdding || dataService.isEditing\" [(ngModel)]=\"dataService.searchTerm\"></ion-searchbar>\r\n                    </ion-col>\r\n               </ion-row>\r\n          </ion-grid>\r\n     </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content *ngIf=\"dataService.isBackendURLSet() && dataService.isLoggedIn\">\r\n     <ion-refresher slot=\"fixed\" (ionRefresh)=\"dataService.pullToRefresh($event,'WatchListItems')\">\r\n          <ion-refresher-content></ion-refresher-content>\r\n     </ion-refresher>\r\n     \r\n     <ion-grid>\r\n          <ion-row>\r\n               <ion-col size=\"6\">\r\n                    <ion-icon *ngIf=\"!dataService.isAdding && !dataService.isEditing\" class=\"addWatchListItem\" name=\"add-outline\" (click)=\"addWatchListItem()\"></ion-icon>\r\n               </ion-col>\r\n          </ion-row>\r\n     </ion-grid>\r\n     \r\n     <div class=\"ion-list-parent\">\r\n          <ion-list>\r\n               <!-- Pagination -->\r\n               <ion-item *ngIf=\"filteredWatchListItems && filteredWatchListItems.length > 0\" lines=\"none\">\r\n                    <span class=\"pageSpan\" *ngIf=\"filteredWatchListItems && filteredWatchListItems.length > dataService.itemsPerPage\">\r\n                         <span class=\"page nomargin\" *ngIf=\"currentPage > 1\" (click)=\"paginationClickHandler(-1)\">Previous</span>\r\n\r\n                         <span class=\"page\" [ngClass]=\"{'active': currentPage === (pageIndex + 1)}\" (click)=\"paginationClickHandler(0,pageIndex + 1)\" *ngFor=\"let number of numSequence(filteredWatchListItems.length/dataService.itemsPerPage > 1 ? math.round(filteredWatchListItems.length/dataService.itemsPerPage) : 1 );let pageIndex=index\">\r\n                              {{ pageIndex + 1 }}\r\n                         </span>\r\n\r\n                         <span class=\"page nomargin\" *ngIf=\"currentPage < filteredWatchListItems.length/dataService.itemsPerPage\" (click)=\"paginationClickHandler(1)\">Next</span>\r\n                    </span>\r\n               </ion-item>\r\n\r\n               <ion-list>\r\n                    <div *ngFor=\"let currWatchListItem of filteredWatchListItems;let index=index\">\r\n                         <ion-item *ngIf=\"isShown(index)\">\r\n                              <ion-grid>\r\n                                   <ion-row class=\"ion-align-items-center\">\r\n                                        <ion-col size=\"1\">\r\n                                             <ion-label>{{ currWatchListItem.WatchListItemID }}</ion-label>\r\n                                        </ion-col>\r\n\r\n                                        <ion-col *ngIf=\"currWatchListItem.IMDB_Poster !== null\" size=\"1\">\r\n                                             <ion-label><img class=\"poster\" src=\"{{currWatchListItem.IMDB_Poster}}\" (click)=\"dataService.openDetailOverlay('watchlist-items',currWatchListItem.WatchListItemID)\"></ion-label>\r\n                                        </ion-col>\r\n\r\n                                        <ion-col [size]=\"dataService.getColumnSize('Type','WatchListItems')\">\r\n                                             <ion-label>{{ dataService.getWatchListTypeName(currWatchListItem.WatchListTypeID) }}</ion-label>\r\n                                        </ion-col>\r\n\r\n                                        <ion-col [size]=\"dataService.getColumnSize('IMDBURL','WatchListItems')\">\r\n                                             <ion-label class=\"header\">IMDB URL: <a *ngIf=\"currWatchListItem.IMDB_URL\" href=\"{{ currWatchListItem.IMDB_URL }}\" target=\"_blank\">{{ currWatchListItem.IMDB_URL }}</a></ion-label>\r\n                                        </ion-col>\r\n                                   </ion-row>\r\n\r\n                                   <ion-row>\r\n                                        <ion-col size=\"1\"></ion-col>\r\n\r\n                                        <ion-col size=\"11\">\r\n                                             <h3 (click)=\"dataService.openDetailOverlay('watchlist-items',currWatchListItem.WatchListItemID)\">{{currWatchListItem.WatchListItemName}}</h3>\r\n                                        </ion-col>\r\n                                   </ion-row>\r\n                              </ion-grid>\r\n                         </ion-item>\r\n                    </div>\r\n               </ion-list>\r\n          </ion-list>\r\n\r\n          <!-- Pagination -->\r\n          <ion-item lines=\"none\">\r\n               <span class=\"pageSpan\" *ngIf=\"filteredWatchListItems && filteredWatchListItems.length > dataService.itemsPerPage\">\r\n                    <span class=\"page nomargin\" *ngIf=\"currentPage > 1\" (click)=\"paginationClickHandler(-1)\">Previous</span>\r\n\r\n                    <span class=\"page\" [ngClass]=\"{'active': currentPage === (pageIndex + 1)}\" (click)=\"paginationClickHandler(0,pageIndex + 1)\" *ngFor=\"let number of numSequence(filteredWatchListItems.length/dataService.itemsPerPage > 1 ? math.round(filteredWatchListItems.length/dataService.itemsPerPage) : 1 );let pageIndex=index\">\r\n                         {{ pageIndex + 1 }}\r\n                    </span>\r\n\r\n                    <span class=\"page nomargin\" *ngIf=\"currentPage < filteredWatchListItems.length/dataService.itemsPerPage\" (click)=\"paginationClickHandler(1)\">Next</span>\r\n               </span>\r\n          </ion-item>\r\n\r\n          <div *ngIf=\"filteredWatchListItems\">{{ filteredWatchListItems.length }} records</div>\r\n     </div>\r\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_components_watchlist-items_watchlist-items_module_ts.js.map