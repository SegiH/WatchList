"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_components_login_login_module_ts"],{

/***/ 9096:
/*!**********************************************************!*\
  !*** ./src/app/components/login/login-routing.module.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageRoutingModule": () => (/* binding */ LoginPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../login/login.component */ 7143);




const routes = [
    {
        path: '',
        component: _login_login_component__WEBPACK_IMPORTED_MODULE_0__.LoginComponent,
    }
];
let LoginPageRoutingModule = class LoginPageRoutingModule {
};
LoginPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], LoginPageRoutingModule);



/***/ }),

/***/ 7143:
/*!*****************************************************!*\
  !*** ./src/app/components/login/login.component.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginComponent": () => (/* binding */ LoginComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _login_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login.component.html?ngResource */ 4437);
/* harmony import */ var _login_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.component.scss?ngResource */ 9436);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _core_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../core/data.service */ 3943);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 3819);






let LoginComponent = class LoginComponent {
    constructor(dataService, platform) {
        this.dataService = dataService;
        this.platform = platform;
        this.backendURL = '';
        this.backendURLVisible = false;
        this.forceBackendURLVisible = false;
        this.loginClickCount = 0;
        this.password = '';
        this.username = '';
        if (this.platform.is('ios') || this.platform.is('android')) {
            this.backendURLVisible = true;
            this.forceBackendURLVisible = true;
        }
    }
    loginClickCountHandler() {
        // Ignore this logic if forceBackendURLVisible = true. This is needed because I don't want to allow the user to hide the backendURL on iOS or Android
        if (this.forceBackendURLVisible)
            return;
        this.loginClickCount++;
        if (this.loginClickCount === 3) {
            this.backendURLVisible = !this.backendURLVisible;
            this.loginClickCount = 0;
        }
    }
    login() {
        if (this.username === null || this.username === '') {
            this.dataService.alert('Please enter the username');
            return;
        }
        if (this.password === null || this.password === '') {
            this.dataService.alert('Please enter the password');
            return;
        }
        if (this.backendURLVisible) {
            if (this.backendURL === null || this.backendURL === '') {
                this.dataService.alert('Please enter the backendURL');
                return;
            }
        }
        else {
            this.backendURL = window.location.origin;
        }
        this.dataService.loginSubscription(this.username, this.password, this.backendURL);
    }
};
LoginComponent.ctorParameters = () => [
    { type: _core_data_service__WEBPACK_IMPORTED_MODULE_2__.DataService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.Platform }
];
LoginComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-login',
        template: _login_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_login_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], LoginComponent);



/***/ }),

/***/ 3872:
/*!**************************************************!*\
  !*** ./src/app/components/login/login.module.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageModule": () => (/* binding */ LoginPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../login/login.component */ 7143);
/* harmony import */ var _login_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login-routing.module */ 9096);







let LoginPageModule = class LoginPageModule {
};
LoginPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _login_routing_module__WEBPACK_IMPORTED_MODULE_1__.LoginPageRoutingModule,
        ],
        declarations: [_login_login_component__WEBPACK_IMPORTED_MODULE_0__.LoginComponent]
    })
], LoginPageModule);



/***/ }),

/***/ 9436:
/*!******************************************************************!*\
  !*** ./src/app/components/login/login.component.scss?ngResource ***!
  \******************************************************************/
/***/ ((module) => {

module.exports = "@media (max-width: 600px) {\n  .ion-list-parent, ion-toolbar {\n    margin-left: unset !important;\n    max-width: unset !important;\n  }\n}\n#login {\n  --background: lightblue;\n  overflow: auto;\n}\n.ion-list-parent {\n  margin-left: 30%;\n  max-width: 20%;\n  height: 100%;\n  overflow: auto;\n}\nion-list.md.list-md {\n  overflow: auto;\n}\nion-toolbar {\n  margin-left: 30%;\n  margin-top: 10%;\n  max-width: 20%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvZ2luLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0k7SUFDSyw2QkFBQTtJQUNBLDJCQUFBO0VBQ1A7QUFDRjtBQUVBO0VBQ0ksdUJBQUE7RUFDQSxjQUFBO0FBQUo7QUFHQTtFQUVJLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7RUFDQSxjQUFBO0FBREo7QUFJQTtFQUNJLGNBQUE7QUFESjtBQUlBO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtBQURKIiwiZmlsZSI6ImxvZ2luLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiQG1lZGlhIChtYXgtd2lkdGg6IDYwMHB4KSB7XHJcbiAgICAuaW9uLWxpc3QtcGFyZW50LCBpb24tdG9vbGJhciB7XHJcbiAgICAgICAgIG1hcmdpbi1sZWZ0OiB1bnNldCAhaW1wb3J0YW50O1xyXG4gICAgICAgICBtYXgtd2lkdGg6IHVuc2V0ICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbn1cclxuXHJcbiNsb2dpbiB7XHJcbiAgICAtLWJhY2tncm91bmQ6IGxpZ2h0Ymx1ZTtcclxuICAgIG92ZXJmbG93OiBhdXRvO1xyXG59XHJcblxyXG4uaW9uLWxpc3QtcGFyZW50IHtcclxuICAgIC8vd2lkdGg6IDEwMCU7XHJcbiAgICBtYXJnaW4tbGVmdDogMzAlO1xyXG4gICAgbWF4LXdpZHRoOiAyMCU7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICBvdmVyZmxvdzogYXV0bztcclxufVxyXG5cclxuaW9uLWxpc3QubWQubGlzdC1tZCB7XHJcbiAgICBvdmVyZmxvdzogYXV0bztcclxufVxyXG5cclxuaW9uLXRvb2xiYXIge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDMwJTtcclxuICAgIG1hcmdpbi10b3A6IDEwJTtcclxuICAgIG1heC13aWR0aDogMjAlO1xyXG59Il19 */";

/***/ }),

/***/ 4437:
/*!******************************************************************!*\
  !*** ./src/app/components/login/login.component.html?ngResource ***!
  \******************************************************************/
/***/ ((module) => {

module.exports = "<ion-content id=\"login\" *ngIf=\"!dataService.isError && dataService.isLoggedInCheckComplete\">\r\n     <ion-toolbar>\r\n          <ion-title (click)=\"loginClickCountHandler()\"><h2>WatchList</h2></ion-title>\r\n    </ion-toolbar>\r\n\r\n    <div class=\"ion-list-parent\">\r\n          <ion-list>\r\n               <ion-item lines=\"full\">\r\n                    <ion-label position=\"floating\">Username</ion-label>\r\n                    <ion-input type=\"text\" [(ngModel)]=\"username\" [value]=\"username\" required (keyup.enter)=\"login()\"></ion-input>\r\n               </ion-item>\r\n\r\n               <ion-item lines=\"full\">\r\n                    <ion-label position=\"floating\">Password</ion-label>\r\n                    <ion-input type=\"password\" [(ngModel)]=\"password\" [value]=\"password\" required (keyup.enter)=\"login()\"></ion-input>\r\n               </ion-item>\r\n\r\n               <ion-item *ngIf=\"backendURLVisible\" lines=\"full\">\r\n                    <ion-label position=\"floating\">Backend URL</ion-label>\r\n                    <ion-input type=\"text\" [(ngModel)]=\"backendURL\" [value]=\"backendURL\" required (keyup.enter)=\"login()\"></ion-input>\r\n               </ion-item>\r\n     \r\n               <ion-button color=\"primary\" expand=\"block\" (click)=\"login()\">Sign In</ion-button>\r\n          </ion-list>\r\n     </div>\r\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_components_login_login_module_ts.js.map