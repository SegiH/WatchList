export default interface WatchListItem {
     WatchListItemID: number,
     WatchListItemName: string,
     WatchListTypeID: number,
     IMDB_URL: string,
     IMDB_Poster: string,
     ItemNotes: string,
     Archived: boolean
}