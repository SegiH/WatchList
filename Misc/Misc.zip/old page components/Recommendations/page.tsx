"use client"

const axios = require("axios");
const exact = require("prop-types-exact");
const IUser = require("../interfaces/IUser");
const PropTypes = require("prop-types");
const React = require("react");
const useCallback = require("react").useCallback;
const useContext = require("react").useContext;
const useRouter = require("next/navigation").useRouter;
const useState = require("react").useState;

import { DataContext, DataContextType } from "../data-context";

export default function Recommendations() {
     const {          
     } = useContext(DataContext) as DataContextType

     return (
          <>
               Recommendations
          </>
     )
}