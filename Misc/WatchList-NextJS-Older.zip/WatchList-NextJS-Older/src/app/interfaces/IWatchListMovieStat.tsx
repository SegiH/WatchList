export default interface IWatchListMovieStat {
     UserID: number,
     WatchListItemName: string,
     ItemCount: number,
     IMDB_URL: string
}