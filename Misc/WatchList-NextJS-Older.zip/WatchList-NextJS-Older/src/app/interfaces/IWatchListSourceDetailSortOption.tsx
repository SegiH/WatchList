export default interface IWatchListSourceDetailSortOption {
     key: string,
     value: string
}