"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_components_watchlist-queue_watchlistqueue_module_ts"],{

/***/ 3137:
/*!*****************************************************************************!*\
  !*** ./src/app/components/watchlist-queue/watchlistqueue-routing.module.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WatchListQueuePageRoutingModule": () => (/* binding */ WatchListQueuePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _watchlistqueue_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlistqueue.page */ 4750);




const routes = [
    {
        path: '',
        component: _watchlistqueue_page__WEBPACK_IMPORTED_MODULE_0__.WatchListQueueComponent,
    }
];
let WatchListQueuePageRoutingModule = class WatchListQueuePageRoutingModule {
};
WatchListQueuePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], WatchListQueuePageRoutingModule);



/***/ }),

/***/ 5880:
/*!*********************************************************************!*\
  !*** ./src/app/components/watchlist-queue/watchlistqueue.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WatchListQueuePageModule": () => (/* binding */ WatchListQueuePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _watchlistqueue_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlistqueue.page */ 4750);
/* harmony import */ var _watchlistqueue_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./watchlistqueue-routing.module */ 3137);







let WatchListQueuePageModule = class WatchListQueuePageModule {
};
WatchListQueuePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _watchlistqueue_routing_module__WEBPACK_IMPORTED_MODULE_1__.WatchListQueuePageRoutingModule
        ],
        declarations: [_watchlistqueue_page__WEBPACK_IMPORTED_MODULE_0__.WatchListQueueComponent]
    })
], WatchListQueuePageModule);



/***/ }),

/***/ 4750:
/*!*******************************************************************!*\
  !*** ./src/app/components/watchlist-queue/watchlistqueue.page.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WatchListQueueComponent": () => (/* binding */ WatchListQueueComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _watchlistqueue_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlistqueue.page.html?ngResource */ 8093);
/* harmony import */ var _watchlistqueue_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./watchlistqueue.page.scss?ngResource */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _core_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../core/data.service */ 3943);





let WatchListQueueComponent = class WatchListQueueComponent {
    constructor(dataService) {
        this.dataService = dataService;
    }
};
WatchListQueueComponent.ctorParameters = () => [
    { type: _core_data_service__WEBPACK_IMPORTED_MODULE_2__.DataService }
];
WatchListQueueComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-watchlistqueue',
        template: _watchlistqueue_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_watchlistqueue_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], WatchListQueueComponent);



/***/ }),

/***/ 2321:
/*!********************************************************************************!*\
  !*** ./src/app/components/watchlist-queue/watchlistqueue.page.scss?ngResource ***!
  \********************************************************************************/
/***/ ((module) => {

module.exports = ".actionColumn {\n  display: inline-flex;\n}\n\n.detailLink {\n  cursor: pointer;\n  text-decoration: underline;\n}\n\n.editSave {\n  margin-right: 10px;\n}\n\n.ion-list-parent {\n  height: 100%;\n  width: 100%;\n  overflow: auto;\n}\n\n.IDColumn, .nameColumn {\n  margin-top: 8px;\n}\n\n.poster {\n  cursor: pointer;\n  max-height: 125px;\n}\n\n.poster:hover {\n  max-height: 250px;\n}\n\nion-content {\n  overflow: auto;\n}\n\nion-grid > ion-row > ion-col > ion-icon.nameArrowIcon,\nion-grid > ion-row > ion-col > ion-icon.IDArrowIcon {\n  width: 50px;\n  position: relative;\n  vertical-align: bottom;\n}\n\nion-grid > ion-row > ion-col > ion-icon.active {\n  color: darkblue;\n}\n\nion-icon {\n  width: 45px !important;\n  height: 45px !important;\n}\n\nion-input {\n  border-style: dashed;\n  border-width: 1px;\n}\n\nion-label {\n  margin-top: 10px;\n}\n\nion-list.md.list-md {\n  min-width: 1000px;\n  overflow: auto;\n}\n\nion-content ion-item {\n  pointer-events: auto;\n}\n\nion-list ion-item ion-grid {\n  background-color: #F1EBE4;\n  border-style: dashed;\n  border-width: 1px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndhdGNobGlzdHF1ZXVlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLG9CQUFBO0FBQ0o7O0FBRUE7RUFDSSxlQUFBO0VBQ0EsMEJBQUE7QUFDSjs7QUFFQTtFQUNJLGtCQUFBO0FBQ0o7O0FBRUE7RUFDSSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGNBQUE7QUFDSjs7QUFFQTtFQUNJLGVBQUE7QUFDSjs7QUFFQTtFQUNJLGVBQUE7RUFDQSxpQkFBQTtBQUNKOztBQUVBO0VBQ0ksaUJBQUE7QUFDSjs7QUFFQTtFQUNJLGNBQUE7QUFDSjs7QUFFQTs7RUFFSyxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxzQkFBQTtBQUNMOztBQUVBO0VBQ0ksZUFBQTtBQUNKOztBQUVBO0VBQ0ksc0JBQUE7RUFDQSx1QkFBQTtBQUNKOztBQUVBO0VBQ0ksb0JBQUE7RUFDQSxpQkFBQTtBQUNKOztBQUVBO0VBQ0ksZ0JBQUE7QUFDSjs7QUFFQTtFQUNJLGlCQUFBO0VBQ0EsY0FBQTtBQUNKOztBQUdJO0VBQ0Usb0JBQUE7QUFBTjs7QUFJQTtFQUNJLHlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxpQkFBQTtBQURKIiwiZmlsZSI6IndhdGNobGlzdHF1ZXVlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5hY3Rpb25Db2x1bW4ge1xyXG4gICAgZGlzcGxheTogaW5saW5lLWZsZXg7XHJcbn1cclxuXHJcbi5kZXRhaWxMaW5rIHtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xyXG59XHJcblxyXG4uZWRpdFNhdmUge1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG59XHJcblxyXG4uaW9uLWxpc3QtcGFyZW50IHtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgb3ZlcmZsb3c6IGF1dG87XHJcbn1cclxuXHJcbi5JRENvbHVtbiwgLm5hbWVDb2x1bW4ge1xyXG4gICAgbWFyZ2luLXRvcDogOHB4O1xyXG59XHJcblxyXG4ucG9zdGVyIHtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIG1heC1oZWlnaHQ6IDEyNXB4O1xyXG59XHJcblxyXG4ucG9zdGVyOmhvdmVyIHtcclxuICAgIG1heC1oZWlnaHQ6IDI1MHB4O1xyXG59XHJcblxyXG5pb24tY29udGVudCB7XHJcbiAgICBvdmVyZmxvdzogYXV0bztcclxufVxyXG5cclxuaW9uLWdyaWQgPiBpb24tcm93ID4gaW9uLWNvbCA+IGlvbi1pY29uLm5hbWVBcnJvd0ljb24sIFxyXG5pb24tZ3JpZCA+IGlvbi1yb3cgPiBpb24tY29sID4gaW9uLWljb24uSURBcnJvd0ljb24ge1xyXG4gICAgIHdpZHRoOiA1MHB4O1xyXG4gICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICB2ZXJ0aWNhbC1hbGlnbjogYm90dG9tO1xyXG59XHJcblxyXG5pb24tZ3JpZCA+IGlvbi1yb3cgPiBpb24tY29sID4gaW9uLWljb24uYWN0aXZlIHtcclxuICAgIGNvbG9yOiBkYXJrYmx1ZVxyXG59XHJcblxyXG5pb24taWNvbiB7XHJcbiAgICB3aWR0aDogNDVweCAhaW1wb3J0YW50O1xyXG4gICAgaGVpZ2h0OiA0NXB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1pbnB1dCB7XHJcbiAgICBib3JkZXItc3R5bGU6IGRhc2hlZDtcclxuICAgIGJvcmRlci13aWR0aDogMXB4O1xyXG59XHJcblxyXG5pb24tbGFiZWwge1xyXG4gICAgbWFyZ2luLXRvcDogMTBweDtcclxufVxyXG5cclxuaW9uLWxpc3QubWQubGlzdC1tZCB7XHJcbiAgICBtaW4td2lkdGg6IDEwMDBweDtcclxuICAgIG92ZXJmbG93OiBhdXRvO1xyXG59XHJcblxyXG5pb24tY29udGVudCB7XHJcbiAgICBpb24taXRlbSB7XHJcbiAgICAgIHBvaW50ZXItZXZlbnRzOiBhdXRvO1xyXG4gICAgfVxyXG59XHJcblxyXG5pb24tbGlzdCBpb24taXRlbSBpb24tZ3JpZCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRjFFQkU0O1xyXG4gICAgYm9yZGVyLXN0eWxlOiBkYXNoZWQ7XHJcbiAgICBib3JkZXItd2lkdGg6IDFweDtcclxufSJdfQ== */";

/***/ }),

/***/ 8093:
/*!********************************************************************************!*\
  !*** ./src/app/components/watchlist-queue/watchlistqueue.page.html?ngResource ***!
  \********************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header [translucent]=\"true\">\r\n     <ion-toolbar>\r\n          <ion-buttons slot=\"start\"> \r\n               <ion-menu-button></ion-menu-button>                \r\n          </ion-buttons>            \r\n          \r\n          <ion-grid>\r\n               <ion-row>\r\n                    <ion-col size=\"12\">\r\n                         <ion-searchbar *ngIf=\"dataService.isBackendURLSet() && dataService.isLoggedIn\"(ionChange)=\"dataService.searchTermChangeHandler($event)\" [disabled]=\"dataService.isAdding || dataService.isEditing\" [(ngModel)]=\"dataService.searchTerm\"></ion-searchbar>\r\n                    </ion-col>\r\n               </ion-row>\r\n          </ion-grid>\r\n     </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content *ngIf=\"dataService.isBackendURLSet() && dataService.isLoggedIn\">\r\n     <ion-refresher slot=\"fixed\" (ionRefresh)=\"dataService.pullToRefresh($event,'WatchListQueueItems')\">\r\n          <ion-refresher-content></ion-refresher-content>\r\n     </ion-refresher>\r\n    \r\n     <ion-grid>\r\n          <ion-row>\r\n               <ion-col size=\"1\">\r\n                    <ion-icon *ngIf=\"!dataService.isAdding && !dataService.isEditing\" class=\"addWatchListQueue\" name=\"add-outline\" (click)=\"this.dataService.openDetailOverlay('watchlist-queue')\"></ion-icon>\r\n               </ion-col>               \r\n          </ion-row>\r\n     </ion-grid>\r\n\r\n     <div class=\"ion-list-parent\">\r\n          <ion-list>\r\n               <div *ngFor=\"let currWatchListQueue of dataService.watchListQueue;let index=index\">\r\n                    <ion-item>\r\n                         <ion-grid>\r\n                              <ion-row class=\"ion-align-items-center\">\r\n                                   <ion-col size=\"1\">\r\n                                        <ion-label>{{ currWatchListQueue.WatchListQueueItemID }}</ion-label>\r\n                                   </ion-col>\r\n\r\n                                   <ion-col [size]=\"this.dataService.getColumnSize('Name','WatchListQueueItems')\" class=\"nameColumn\">\r\n                                        <img *ngIf=\"currWatchListQueue.IMDB_Poster !== null\" class=\"poster\" src=\"{{currWatchListQueue.IMDB_Poster}}\" (click)=\"this.dataService.openDetailOverlay('watchlist-queue',currWatchListQueue.WatchListQueueItemID)\">\r\n                                   </ion-col>\r\n\r\n                                   <ion-col [size]=\"this.dataService.getColumnSize('Notes','WatchListQueueItems')\">\r\n                                        <ion-label>{{ currWatchListQueue.Notes }}</ion-label>\r\n                                   </ion-col>\r\n                              </ion-row>\r\n\r\n                              <ion-row>\r\n                                   <ion-col size=\"1\"></ion-col>\r\n\r\n                                   <ion-col>\r\n                                        <h3 (click)=\"this.dataService.openDetailOverlay('watchlist-queue',currWatchListQueue.WatchListQueueItemID)\">{{ currWatchListQueue.WatchListItemName }}</h3>\r\n                                   </ion-col>\r\n                              </ion-row>\r\n                         </ion-grid>\r\n                    </ion-item>\r\n               </div>\r\n               <!-- Table headers -->\r\n               <!--<ion-item>\r\n                    <ion-grid>\r\n                         <ion-row>\r\n                              <ion-col [size]=\"this.dataService.getColumnSize('ID','WatchListQueueItems')\">\r\n                                   <ion-label>ID</ion-label>\r\n                              </ion-col>\r\n\r\n                              <ion-col [size]=\"this.dataService.getColumnSize('Name','WatchListQueueItems')\">\r\n                                   <ion-label>Name</ion-label>\r\n                              </ion-col>\r\n  \r\n                              <ion-col [size]=\"this.dataService.getColumnSize('Notes','WatchListQueueItems')\">\r\n                                   <ion-label>Notes</ion-label>\r\n                              </ion-col>\r\n                        </ion-row>\r\n                    </ion-grid>               \r\n               </ion-item>-->\r\n\r\n               <!-- Data Panel -->\r\n               <!--<ion-item *ngFor=\"let currWatchListQueue of dataService.watchListQueue\">\r\n                    <ion-grid>\r\n                         <ion-row>\r\n                              <ion-col [size]=\"this.dataService.getColumnSize('ID','WatchListQueueItems')\" class=\"nameColumn\">\r\n                                   <ion-label className=\"WatchListItemID\">\r\n                                        {{ currWatchListQueue.WatchListItemID }}\r\n                                   </ion-label>\r\n                              </ion-col>\r\n\r\n                              <ion-col [size]=\"this.dataService.getColumnSize('Name','WatchListQueueItems')\" class=\"nameColumn\">\r\n                                   <ion-label class=\"poster\" className=\"WatchListItemName\" (click)=\"this.dataService.openDetailOverlay('watchlist-queue',currWatchListQueue.WatchListQueueItemID)\">\r\n                                        {{ currWatchListQueue.WatchListItemName }}\r\n                                   </ion-label>\r\n\r\n                                   <img *ngIf=\"currWatchListQueue.IMDB_Poster !== null\" class=\"poster\" src=\"{{currWatchListQueue.IMDB_Poster}}\" (click)=\"this.dataService.openDetailOverlay('watchlist-queue',currWatchListQueue.WatchListQueueItemID)\">\r\n                              </ion-col>\r\n                \r\n                              <ion-col [size]=\"this.dataService.getColumnSize('Notes','WatchListQueueItems')\">\r\n                                   {{ currWatchListQueue.Notes }}\r\n                              </ion-col>\r\n                         </ion-row>\r\n                    </ion-grid>\r\n                </ion-item>-->\r\n          </ion-list>\r\n     </div>\r\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_components_watchlist-queue_watchlistqueue_module_ts.js.map