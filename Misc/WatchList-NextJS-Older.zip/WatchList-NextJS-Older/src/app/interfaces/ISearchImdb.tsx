export default interface SearchIMDB {
     Title: string,
     Year: string,
     ImdbID: string,
     Type: string,
     Poster: string 
}