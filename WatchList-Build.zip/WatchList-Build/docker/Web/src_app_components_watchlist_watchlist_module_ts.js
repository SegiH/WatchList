"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_components_watchlist_watchlist_module_ts"],{

/***/ 9285:
/*!******************************************************************!*\
  !*** ./src/app/components/watchlist/watchlist-routing.module.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WatchListPageRoutingModule": () => (/* binding */ WatchListPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _watchlist_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlist.page */ 3199);




const routes = [
    {
        path: '',
        component: _watchlist_page__WEBPACK_IMPORTED_MODULE_0__.WatchListComponent,
    }
];
let WatchListPageRoutingModule = class WatchListPageRoutingModule {
};
WatchListPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], WatchListPageRoutingModule);



/***/ }),

/***/ 7690:
/*!**********************************************************!*\
  !*** ./src/app/components/watchlist/watchlist.module.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WatchListPageModule": () => (/* binding */ WatchListPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _watchlist_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlist.page */ 3199);
/* harmony import */ var _watchlist_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./watchlist-routing.module */ 9285);







let WatchListPageModule = class WatchListPageModule {
};
WatchListPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _watchlist_routing_module__WEBPACK_IMPORTED_MODULE_1__.WatchListPageRoutingModule,
        ],
        declarations: [_watchlist_page__WEBPACK_IMPORTED_MODULE_0__.WatchListComponent]
    })
], WatchListPageModule);



/***/ }),

/***/ 3199:
/*!********************************************************!*\
  !*** ./src/app/components/watchlist/watchlist.page.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WatchListComponent": () => (/* binding */ WatchListComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _watchlist_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlist.page.html?ngResource */ 6952);
/* harmony import */ var _watchlist_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./watchlist.page.scss?ngResource */ 1103);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _core_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../core/data.service */ 3943);





let WatchListComponent = class WatchListComponent {
    constructor(dataService) {
        this.dataService = dataService;
        this.currentPage = 1;
        this.math = Math;
    }
    ngDoCheck() {
        if (this.dataService.incompleteFilter === null) {
            this.dataService.incompleteFilter = true;
        }
        if (this.dataService.recordLimit === null) {
            this.dataService.recordLimit = 50;
        }
        if (typeof this.dataService.watchList !== 'undefined' && this.dataService.watchList.length > 0) {
            this.filteredWatchList = this.dataService.watchList.filter((wl, index) => {
                return ((this.dataService.searchTerm === ""
                    || (this.dataService.searchTerm !== ""
                        && (this.dataService.getWatchListItemName(wl.WatchListItemID).toLowerCase().includes(this.dataService.searchTerm.toLowerCase())
                            || (wl.WatchListSourceID !== null && this.dataService.getSourceName(wl.WatchListSourceID).toLowerCase().includes(this.dataService.searchTerm.toLowerCase()))
                            || (wl.Notes !== null && wl.Notes.toLowerCase().includes(this.dataService.searchTerm.toLowerCase())))))
                    &&
                        ((this.dataService.incompleteFilter === true && wl.EndDate === null)
                            || (this.dataService.incompleteFilter !== true && wl.EndDate !== null)));
            });
            if (this.filteredWatchList.length > this.dataService.recordLimit)
                this.filteredWatchList.length = this.dataService.recordLimit;
        }
    }
    addWatchList() {
        this.dataService.openDetailOverlay('watchlist', null);
    }
    isShown(pageIndex) {
        if (typeof this.filteredWatchList !== 'undefined' && this.filteredWatchList.length < this.dataService.itemsPerPage)
            return true;
        if (pageIndex >= ((this.currentPage - 1) * this.dataService.itemsPerPage) && pageIndex < ((this.currentPage - 1) * this.dataService.itemsPerPage) + this.dataService.itemsPerPage)
            return true;
        return false;
    }
    numSequence(n) {
        if (isNaN(n)) {
            alert(`${n} is not valid`);
            return;
        }
        return Array(n);
    }
    paginationClickHandler(relativePage, absolutePage) {
        if (relativePage === -1 || relativePage === 1)
            this.currentPage += relativePage;
        else if (absolutePage)
            this.currentPage = absolutePage;
    }
};
WatchListComponent.ctorParameters = () => [
    { type: _core_data_service__WEBPACK_IMPORTED_MODULE_2__.DataService }
];
WatchListComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-watchlist',
        template: _watchlist_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_watchlist_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], WatchListComponent);



/***/ }),

/***/ 1103:
/*!*********************************************************************!*\
  !*** ./src/app/components/watchlist/watchlist.page.scss?ngResource ***!
  \*********************************************************************/
/***/ ((module) => {

module.exports = ".actionColumn {\n  display: inline-flex;\n}\n\n.detailLink {\n  cursor: pointer;\n  text-decoration: underline;\n}\n\n.IDColumn, .nameColumn {\n  margin-top: 8px;\n}\n\n.ion-list-parent {\n  width: 100%;\n  height: 100%;\n  overflow: auto;\n}\n\n.item-inner {\n  border-style: hidden;\n}\n\n.nomargin {\n  margin-left: 0px;\n  margin-right: 0px;\n}\n\n.page {\n  cursor: pointer;\n  padding-left: 5px;\n  padding-right: 5px;\n  border: 1px solid #ddd;\n  color: black;\n  float: left;\n  padding: 8px 16px;\n  text-decoration: none;\n  overflow-x: visible;\n  height: 40px;\n  vertical-align: middle;\n}\n\n.page:first-child {\n  border-top-left-radius: 5px;\n  border-bottom-left-radius: 5px;\n}\n\n.page:last-child {\n  border-top-right-radius: 5px;\n  border-bottom-right-radius: 5px;\n}\n\n.page.active {\n  background-color: #4285f4;\n  color: white;\n}\n\n.pageSelect {\n  width: 65px;\n}\n\n.pageSpan {\n  display: flex;\n  overflow: auto;\n  width: -moz-fit-content;\n  width: fit-content;\n  border-style: dashed;\n  border-width: 1px;\n}\n\n.poster {\n  cursor: pointer;\n  max-height: 125px;\n}\n\n.poster:hover {\n  max-height: 250px;\n}\n\nspan > .page:first-child {\n  border-top-left-radius: 5px;\n  border-bottom-left-radius: 5px;\n}\n\nspan > .page:last-child {\n  border-top-right-radius: 5px;\n  border-bottom-right-radius: 5px;\n}\n\nion-card {\n  display: flex;\n  width: 100%;\n}\n\nion-content {\n  overflow: auto;\n}\n\nion-grid > ion-row > ion-col > ion-icon.NameArrowIcon,\nion-grid > ion-row > ion-col > ion-icon.IDArrowIcon,\nion-grid > ion-row > ion-col > ion-icon.StartDateArrowIcon,\nion-grid > ion-row > ion-col > ion-icon.EndDateArrowIcon,\nion-grid > ion-row > ion-col > ion-icon.SourceArrowIcon {\n  width: 30px;\n  position: relative;\n  vertical-align: bottom;\n}\n\nion-grid > ion-row > ion-col > ion-icon.active {\n  color: #30A199;\n}\n\nion-icon {\n  width: 45px;\n  height: 45px;\n  cursor: pointer;\n}\n\nion-icon.header {\n  vertical-align: middle !important;\n}\n\nion-input {\n  border-style: dashed;\n  border-width: 1px;\n}\n\nion-label {\n  margin-top: 10px;\n}\n\nion-label.header {\n  display: inline;\n}\n\nion-list.md.list-md {\n  min-width: 1000px;\n  overflow: auto;\n}\n\nion-select {\n  border-style: dashed;\n  border-width: 1px;\n  max-width: 100%;\n}\n\nion-item > ion-grid > ion-row > ion-col > ion-label {\n  word-break: break-all;\n  overflow-wrap: break-word;\n  word-wrap: break-word;\n  -webkit-hyphens: auto;\n          hyphens: auto;\n  overflow: auto;\n}\n\nion-item > ion-grid > ion-row > ion-col > ion-input {\n  overflow: auto;\n}\n\nion-list ion-item ion-grid {\n  background-color: #F1EBE4;\n  border-style: dashed;\n  border-width: 1px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndhdGNobGlzdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSyxvQkFBQTtBQUNMOztBQUVBO0VBQ0ssZUFBQTtFQUNBLDBCQUFBO0FBQ0w7O0FBRUE7RUFDSyxlQUFBO0FBQ0w7O0FBRUE7RUFDSyxXQUFBO0VBQ0EsWUFBQTtFQUNBLGNBQUE7QUFDTDs7QUFFQTtFQUNLLG9CQUFBO0FBQ0w7O0FBRUE7RUFDSyxnQkFBQTtFQUNBLGlCQUFBO0FBQ0w7O0FBRUE7RUFDSyxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtFQUNBLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0Esc0JBQUE7QUFDTDs7QUFFQTtFQUNLLDJCQUFBO0VBQ0EsOEJBQUE7QUFDTDs7QUFFQTtFQUNLLDRCQUFBO0VBQ0EsK0JBQUE7QUFDTDs7QUFFQTtFQUNJLHlCQUFBO0VBQ0EsWUFBQTtBQUNKOztBQUVBO0VBQ0ssV0FBQTtBQUNMOztBQUVBO0VBQ0ssYUFBQTtFQUNBLGNBQUE7RUFDQSx1QkFBQTtFQUFBLGtCQUFBO0VBQ0Esb0JBQUE7RUFDQSxpQkFBQTtBQUNMOztBQUVBO0VBQ0ssZUFBQTtFQUNBLGlCQUFBO0FBQ0w7O0FBRUE7RUFDSyxpQkFBQTtBQUNMOztBQUVBO0VBQ0ssMkJBQUE7RUFDQSw4QkFBQTtBQUNMOztBQUVBO0VBQ0ssNEJBQUE7RUFDQSwrQkFBQTtBQUNMOztBQUVBO0VBQ0ssYUFBQTtFQUNBLFdBQUE7QUFDTDs7QUFFQTtFQUNLLGNBQUE7QUFDTDs7QUFFQTs7Ozs7RUFLSyxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxzQkFBQTtBQUNMOztBQUVBO0VBQ0ssY0FBQTtBQUNMOztBQUVBO0VBQ0ssV0FBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0FBQ0w7O0FBRUE7RUFDSyxpQ0FBQTtBQUNMOztBQUVBO0VBQ0ssb0JBQUE7RUFDQSxpQkFBQTtBQUNMOztBQUVBO0VBQ0ssZ0JBQUE7QUFDTDs7QUFFQTtFQUNLLGVBQUE7QUFDTDs7QUFFQTtFQUNLLGlCQUFBO0VBQ0EsY0FBQTtBQUNMOztBQUVBO0VBQ0ssb0JBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7QUFDTDs7QUFFQTtFQUNLLHFCQUFBO0VBQ0EseUJBQUE7RUFDQSxxQkFBQTtFQUNBLHFCQUFBO1VBQUEsYUFBQTtFQUNBLGNBQUE7QUFDTDs7QUFFQTtFQUNLLGNBQUE7QUFDTDs7QUFFQTtFQUNLLHlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxpQkFBQTtBQUNMIiwiZmlsZSI6IndhdGNobGlzdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYWN0aW9uQ29sdW1uIHtcclxuICAgICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcclxufVxyXG5cclxuLmRldGFpbExpbmsge1xyXG4gICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcclxufVxyXG5cclxuLklEQ29sdW1uLCAubmFtZUNvbHVtbiB7XHJcbiAgICAgbWFyZ2luLXRvcDogOHB4O1xyXG59XHJcblxyXG4uaW9uLWxpc3QtcGFyZW50IHtcclxuICAgICB3aWR0aDogMTAwJTtcclxuICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAgb3ZlcmZsb3c6IGF1dG87XHJcbn1cclxuXHJcbi5pdGVtLWlubmVyIHtcclxuICAgICBib3JkZXItc3R5bGU6IGhpZGRlbjtcclxufVxyXG5cclxuLm5vbWFyZ2luIHtcclxuICAgICBtYXJnaW4tbGVmdDogMHB4O1xyXG4gICAgIG1hcmdpbi1yaWdodDogMHB4O1xyXG59XHJcblxyXG4ucGFnZSB7XHJcbiAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgIHBhZGRpbmctbGVmdDogNXB4O1xyXG4gICAgIHBhZGRpbmctcmlnaHQ6IDVweDtcclxuICAgICBib3JkZXI6IDFweCBzb2xpZCAjZGRkO1xyXG4gICAgIGNvbG9yOiBibGFjaztcclxuICAgICBmbG9hdDogbGVmdDtcclxuICAgICBwYWRkaW5nOiA4cHggMTZweDtcclxuICAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbiAgICAgb3ZlcmZsb3cteDogdmlzaWJsZTtcclxuICAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcclxufVxyXG5cclxuLnBhZ2U6Zmlyc3QtY2hpbGQge1xyXG4gICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDVweDtcclxuICAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiA1cHg7XHJcbiAgIH1cclxuICAgXHJcbi5wYWdlOmxhc3QtY2hpbGQge1xyXG4gICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiA1cHg7XHJcbiAgICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDVweDtcclxufVxyXG5cclxuLnBhZ2UuYWN0aXZlIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICM0Mjg1ZjQ7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbn1cclxuXHJcbi5wYWdlU2VsZWN0IHtcclxuICAgICB3aWR0aDogNjVweDtcclxufVxyXG5cclxuLnBhZ2VTcGFuIHtcclxuICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgIG92ZXJmbG93OiBhdXRvO1xyXG4gICAgIHdpZHRoOiBmaXQtY29udGVudDtcclxuICAgICBib3JkZXItc3R5bGU6IGRhc2hlZDtcclxuICAgICBib3JkZXItd2lkdGg6IDFweDtcclxufVxyXG5cclxuLnBvc3RlciB7XHJcbiAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgIG1heC1oZWlnaHQ6IDEyNXB4O1xyXG59XHJcblxyXG4ucG9zdGVyOmhvdmVyIHtcclxuICAgICBtYXgtaGVpZ2h0OiAyNTBweDtcclxufVxyXG5cclxuc3BhbiA+IC5wYWdlOmZpcnN0LWNoaWxkIHtcclxuICAgICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiA1cHg7XHJcbiAgICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogNXB4O1xyXG59XHJcbiAgICAgXHJcbnNwYW4gPiAucGFnZTpsYXN0LWNoaWxkIHtcclxuICAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogNXB4O1xyXG4gICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA1cHg7XHJcbn1cclxuXHJcbmlvbi1jYXJkIHtcclxuICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgIHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG5pb24tY29udGVudCB7XHJcbiAgICAgb3ZlcmZsb3c6IGF1dG87XHJcbn1cclxuXHJcbmlvbi1ncmlkID4gaW9uLXJvdyA+IGlvbi1jb2wgPiBpb24taWNvbi5OYW1lQXJyb3dJY29uLFxyXG5pb24tZ3JpZCA+IGlvbi1yb3cgPiBpb24tY29sID4gaW9uLWljb24uSURBcnJvd0ljb24sXHJcbmlvbi1ncmlkID4gaW9uLXJvdyA+IGlvbi1jb2wgPiBpb24taWNvbi5TdGFydERhdGVBcnJvd0ljb24sXHJcbmlvbi1ncmlkID4gaW9uLXJvdyA+IGlvbi1jb2wgPiBpb24taWNvbi5FbmREYXRlQXJyb3dJY29uLFxyXG5pb24tZ3JpZCA+IGlvbi1yb3cgPiBpb24tY29sID4gaW9uLWljb24uU291cmNlQXJyb3dJY29uIHtcclxuICAgICB3aWR0aDogMzBweDtcclxuICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgdmVydGljYWwtYWxpZ246IGJvdHRvbTtcclxufVxyXG5cclxuaW9uLWdyaWQgPiBpb24tcm93ID4gaW9uLWNvbCA+IGlvbi1pY29uLmFjdGl2ZSB7XHJcbiAgICAgY29sb3I6ICMzMEExOTk7XHJcbn1cclxuXHJcbmlvbi1pY29uIHtcclxuICAgICB3aWR0aDogNDVweDtcclxuICAgICBoZWlnaHQ6IDQ1cHg7XHJcbiAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcblxyXG5pb24taWNvbi5oZWFkZXIge1xyXG4gICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGUgIWltcG9ydGFudDtcclxufVxyXG5cclxuaW9uLWlucHV0IHtcclxuICAgICBib3JkZXItc3R5bGU6IGRhc2hlZDtcclxuICAgICBib3JkZXItd2lkdGg6IDFweDtcclxufVxyXG5cclxuaW9uLWxhYmVsIHtcclxuICAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG59XHJcblxyXG5pb24tbGFiZWwuaGVhZGVyIHtcclxuICAgICBkaXNwbGF5OiBpbmxpbmU7XHJcbn1cclxuXHJcbmlvbi1saXN0Lm1kLmxpc3QtbWQge1xyXG4gICAgIG1pbi13aWR0aDogMTAwMHB4O1xyXG4gICAgIG92ZXJmbG93OiBhdXRvO1xyXG59XHJcblxyXG5pb24tc2VsZWN0IHtcclxuICAgICBib3JkZXItc3R5bGU6IGRhc2hlZDtcclxuICAgICBib3JkZXItd2lkdGg6IDFweDtcclxuICAgICBtYXgtd2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbmlvbi1pdGVtID4gaW9uLWdyaWQgPiBpb24tcm93ID4gaW9uLWNvbCA+IGlvbi1sYWJlbCB7XHJcbiAgICAgd29yZC1icmVhazogYnJlYWstYWxsO1xyXG4gICAgIG92ZXJmbG93LXdyYXA6IGJyZWFrLXdvcmQ7XHJcbiAgICAgd29yZC13cmFwOiBicmVhay13b3JkO1xyXG4gICAgIGh5cGhlbnM6IGF1dG87XHJcbiAgICAgb3ZlcmZsb3c6IGF1dG87XHJcbn1cclxuXHJcbmlvbi1pdGVtID4gaW9uLWdyaWQgPiBpb24tcm93ID4gaW9uLWNvbCA+IGlvbi1pbnB1dCB7XHJcbiAgICAgb3ZlcmZsb3c6IGF1dG87XHJcbn1cclxuXHJcbmlvbi1saXN0IGlvbi1pdGVtIGlvbi1ncmlkIHtcclxuICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRjFFQkU0O1xyXG4gICAgIGJvcmRlci1zdHlsZTogZGFzaGVkO1xyXG4gICAgIGJvcmRlci13aWR0aDogMXB4O1xyXG59XHJcbiJdfQ== */";

/***/ }),

/***/ 6952:
/*!*********************************************************************!*\
  !*** ./src/app/components/watchlist/watchlist.page.html?ngResource ***!
  \*********************************************************************/
/***/ ((module) => {

module.exports = "<ion-header [translucent]=\"true\">\r\n     <ion-toolbar *ngIf=\"!dataService.isError\">\r\n          <ion-buttons slot=\"start\"> \r\n               <ion-menu-button></ion-menu-button>                \r\n          </ion-buttons>\r\n\r\n          <ion-grid>\r\n               <ion-row>\r\n                    <ion-col size=\"12\">\r\n                         <ion-searchbar *ngIf=\"dataService.isBackendURLSet() && dataService.isLoggedIn\"(ionChange)=\"dataService.searchTermChangeHandler($event)\" [disabled]=\"dataService.isAdding || dataService.isEditing\" [(ngModel)]=\"dataService.searchTerm\"></ion-searchbar>\r\n                    </ion-col>\r\n               </ion-row>\r\n          </ion-grid>\r\n     </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content *ngIf=\"dataService.isBackendURLSet() && dataService.isLoggedIn\">\r\n     <ion-refresher slot=\"fixed\" (ionRefresh)=\"dataService.pullToRefresh($event,'WatchList')\">\r\n          <ion-refresher-content></ion-refresher-content>\r\n     </ion-refresher>\r\n\r\n     <ion-grid *ngIf=\"!dataService.isError\">\r\n          <ion-row>\r\n               <ion-col size=\"6\">\r\n                    <ion-icon *ngIf=\"!dataService.isAdding && !dataService.isEditing\" name=\"add-outline\" (click)=\"addWatchList()\"></ion-icon>\r\n               </ion-col>\r\n          </ion-row>\r\n     </ion-grid>\r\n\r\n     <div class=\"ion-list-parent\">\r\n          <ion-list lines=\"none\">\r\n               <!-- Pagination -->\r\n               <ion-item *ngIf=\"filteredWatchList && filteredWatchList.length > 0\" lines=\"none\">\r\n                    <span class=\"pageSpan\" *ngIf=\"filteredWatchList && filteredWatchList.length > dataService.itemsPerPage\">\r\n                         <span class=\"page nomargin\" *ngIf=\"currentPage > 1\" (click)=\"paginationClickHandler(-1)\">Previous</span>\r\n\r\n                         <span class=\"page\" [ngClass]=\"{'active': currentPage === (pageIndex + 1)}\" (click)=\"paginationClickHandler(0,pageIndex + 1)\" *ngFor=\"let number of numSequence(filteredWatchList.length/dataService.itemsPerPage > 1 ? math.round(filteredWatchList.length/dataService.itemsPerPage) : 1 );let pageIndex=index\">\r\n                              {{ pageIndex + 1 }}\r\n                         </span>\r\n\r\n                         <span class=\"page nomargin\" *ngIf=\"currentPage < filteredWatchList.length/dataService.itemsPerPage\" (click)=\"paginationClickHandler(1)\">Next</span>\r\n                    </span>\r\n               </ion-item>\r\n\r\n               <ion-list>\r\n                    <div *ngFor=\"let currWatchList of filteredWatchList;let index=index\">\r\n                         <ion-item *ngIf=\"isShown(index)\">\r\n                              <ion-grid>\r\n                                   <ion-row class=\"ion-align-items-center\">\r\n                                        <ion-col size=\"1\">\r\n                                             <ion-label>{{ currWatchList.WatchListID }}</ion-label>\r\n                                        </ion-col>\r\n\r\n                                        <ion-col *ngIf=\"currWatchList.IMDB_Poster !== null\" size=\"1\">\r\n                                             <ion-label><img class=\"poster\" src=\"{{currWatchList.IMDB_Poster}}\" (click)=\"dataService.openDetailOverlay('watchlist',currWatchList.WatchListID)\"></ion-label>\r\n                                        </ion-col>\r\n\r\n                                        <ion-col size=\"4\">\r\n                                             <ion-label>{{(currWatchList.EndDate === null ? 'Started watching' : 'Watched')}} <br /> <br /> {{ currWatchList.StartDate | date:\"MM/dd/yyyy\" }}<span *ngIf=\"currWatchList.EndDate !== null\"> - {{currWatchList.EndDate | date:\"MM/dd/yyyy\"}}</span></ion-label>\r\n                                        </ion-col>\r\n\r\n                                        <ion-col size=\"2\">\r\n                                             <ion-label>\r\n                                                  {{ dataService.getSourceName(currWatchList.WatchListSourceID) }}\r\n                                             </ion-label>\r\n                                        </ion-col>\r\n\r\n                                        <ion-col size=\"2\">\r\n                                             <ion-label *ngIf=\"currWatchList.Season !== null\">\r\n                                                  Season {{ currWatchList.Season }}\r\n                                             </ion-label>\r\n                                        </ion-col>\r\n\r\n                                        <ion-col size=\"2\">\r\n                                             <ion-label *ngIf=\"currWatchList['Rating'] !== null\">\r\n                                                  {{ currWatchList.Rating }} <span>/ {{ dataService.ratingMax }}</span>\r\n                                             </ion-label>\r\n                                        </ion-col>\r\n                                   </ion-row>\r\n\r\n                                   <ion-row>\r\n                                        <ion-col size=\"1\"></ion-col>\r\n\r\n                                        <ion-col size=\"11\">\r\n                                             <h3 (click)=\"dataService.openDetailOverlay('watchlist',currWatchList.WatchListID)\">{{dataService.getWatchListItemName(currWatchList.WatchListItemID)}}</h3>\r\n                                        </ion-col>\r\n                                   </ion-row>\r\n                              </ion-grid>\r\n                         </ion-item>\r\n                    </div>\r\n               </ion-list>\r\n\r\n               <!-- Pagination -->\r\n               <ion-item lines=\"none\">\r\n                    <span class=\"pageSpan\" *ngIf=\"filteredWatchList && filteredWatchList.length > dataService.itemsPerPage\">\r\n                         <span class=\"page nomargin\" *ngIf=\"currentPage > 1\" (click)=\"paginationClickHandler(-1)\">Previous</span>\r\n\r\n                         <span class=\"page\" [ngClass]=\"{'active': currentPage === (pageIndex + 1)}\" (click)=\"paginationClickHandler(0,pageIndex + 1)\" *ngFor=\"let number of numSequence(filteredWatchList.length/dataService.itemsPerPage > 1 ? math.round(filteredWatchList.length/dataService.itemsPerPage) : 1 );let pageIndex=index\">\r\n                              {{ pageIndex + 1 }}\r\n                         </span>\r\n\r\n                         <span class=\"page nomargin\" *ngIf=\"currentPage < filteredWatchList.length/dataService.itemsPerPage\" (click)=\"paginationClickHandler(1)\">Next</span>\r\n                    </span>\r\n               </ion-item>\r\n          </ion-list>\r\n          \r\n          <div *ngIf=\"filteredWatchList\">{{ filteredWatchList.length }} records</div>\r\n     </div>\r\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_components_watchlist_watchlist_module_ts.js.map