"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tabs_tabs_module_ts"],{

/***/ 2699:
/*!********************************************************************************!*\
  !*** ./src/app/components/watchlist-detail/watchlist-detail-routing.module.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WatchListDetailPageRoutingModule": () => (/* binding */ WatchListDetailPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _watchlist_detail_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlist-detail-page */ 5027);




const routes = [
    {
        path: '',
        component: _watchlist_detail_page__WEBPACK_IMPORTED_MODULE_0__.WatchListDetailComponent,
    }
];
let WatchListDetailPageRoutingModule = class WatchListDetailPageRoutingModule {
};
WatchListDetailPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], WatchListDetailPageRoutingModule);



/***/ }),

/***/ 3117:
/*!********************************************************************************************!*\
  !*** ./src/app/components/watchlist-items-detail/watchlist-items-detail-routing.module.ts ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WatchListItemsDetailPageRoutingModule": () => (/* binding */ WatchListItemsDetailPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _watchlist_items_detail_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlist-items-detail-page */ 7897);




const routes = [
    {
        path: '',
        component: _watchlist_items_detail_page__WEBPACK_IMPORTED_MODULE_0__.WatchListItemsDetailComponent,
    }
];
let WatchListItemsDetailPageRoutingModule = class WatchListItemsDetailPageRoutingModule {
};
WatchListItemsDetailPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], WatchListItemsDetailPageRoutingModule);



/***/ }),

/***/ 4971:
/*!********************************************************************************************!*\
  !*** ./src/app/components/watchlist-queue-detail/watchlist-queue-detail-routing.module.ts ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WatchListQueueDetailPageRoutingModule": () => (/* binding */ WatchListQueueDetailPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _watchlist_queue_detail_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./watchlist-queue-detail-page */ 6417);




const routes = [
    {
        path: '',
        component: _watchlist_queue_detail_page__WEBPACK_IMPORTED_MODULE_0__.WatchListQueueDetailComponent,
    }
];
let WatchListQueueDetailPageRoutingModule = class WatchListQueueDetailPageRoutingModule {
};
WatchListQueueDetailPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], WatchListQueueDetailPageRoutingModule);



/***/ }),

/***/ 9097:
/*!********************************************!*\
  !*** ./src/app/core/auth-guard-service.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthGuardService": () => (/* binding */ AuthGuardService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./data.service */ 3943);




let AuthGuardService = class AuthGuardService {
    constructor(dataService, router) {
        this.dataService = dataService;
        this.router = router;
    }
    canActivate() {
        if (!this.dataService.isLoggedIn) {
            this.router.navigateByUrl('/tabs/login');
            return;
        }
        // Prevents switching tabs while adding or editing an item. Prevents switching to a DIFFERENT component
        if (this.dataService.detailObjectName !== null && this.dataService.detailObjectName.toLowerCase() !== this.router.url.replace('/tabs/', '').toLowerCase() && !this.dataService.authGuardDisabled) {
            this.dataService.alert(`Please save or cancel the detail before switching tabs`);
            return false;
        }
        return true;
    }
};
AuthGuardService.ctorParameters = () => [
    { type: _data_service__WEBPACK_IMPORTED_MODULE_0__.DataService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__.Router }
];
AuthGuardService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], AuthGuardService);



/***/ }),

/***/ 530:
/*!*********************************************!*\
  !*** ./src/app/tabs/tabs-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TabsPageRoutingModule": () => (/* binding */ TabsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _tabs_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tabs.page */ 7942);
/* harmony import */ var _core_auth_guard_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../core/auth-guard-service */ 9097);





const routes = [
    {
        path: 'tabs',
        component: _tabs_page__WEBPACK_IMPORTED_MODULE_0__.TabsComponent,
        children: [
            {
                path: 'login',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_components_login_login_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../components/login/login.module */ 3872)).then(m => m.LoginPageModule)
            },
            {
                path: 'watchlist',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_components_watchlist_watchlist_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../components/watchlist/watchlist.module */ 7690)).then(m => m.WatchListPageModule),
                canActivate: [_core_auth_guard_service__WEBPACK_IMPORTED_MODULE_1__.AuthGuardService]
            },
            {
                path: 'watchlist-items',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_components_watchlist-items_watchlist-items_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../components/watchlist-items/watchlist-items.module */ 4078)).then(m => m.WatchListItemsPageModule),
                canActivate: [_core_auth_guard_service__WEBPACK_IMPORTED_MODULE_1__.AuthGuardService]
            },
            {
                path: 'watchlist-queue',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_components_watchlist-queue_watchlistqueue_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../components/watchlist-queue/watchlistqueue.module */ 5880)).then(m => m.WatchListQueuePageModule),
                canActivate: [_core_auth_guard_service__WEBPACK_IMPORTED_MODULE_1__.AuthGuardService]
            },
            {
                path: 'imdb-search',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_components_imdb-search_imdb-search_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../components/imdb-search/imdb-search.module */ 8085)).then(m => m.IMDBSearchPageModule),
                canActivate: [_core_auth_guard_service__WEBPACK_IMPORTED_MODULE_1__.AuthGuardService]
            },
            {
                path: 'watchlist-stats',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_components_watchlist-stats_watchlist-stats_modules_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../components/watchlist-stats/watchlist-stats.modules */ 4498)).then(m => m.WatchListStatsPageModule),
                canActivate: [_core_auth_guard_service__WEBPACK_IMPORTED_MODULE_1__.AuthGuardService]
            },
            {
                path: 'detail-overlay',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_components_detail-overlay_detail-overlay_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../components/detail-overlay/detail-overlay.module */ 4409)).then(m => m.DetailOverlayPageModule),
                canActivate: [_core_auth_guard_service__WEBPACK_IMPORTED_MODULE_1__.AuthGuardService]
            }
        ]
    },
    {
        path: '',
        redirectTo: '/tabs/login',
        pathMatch: 'full'
    }
];
let TabsPageRoutingModule = class TabsPageRoutingModule {
};
TabsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)],
    })
], TabsPageRoutingModule);



/***/ }),

/***/ 5564:
/*!*************************************!*\
  !*** ./src/app/tabs/tabs.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TabsPageModule": () => (/* binding */ TabsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _tabs_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tabs-routing.module */ 530);
/* harmony import */ var _tabs_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tabs.page */ 7942);
/* harmony import */ var _components_watchlist_detail_watchlist_detail_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/watchlist-detail/watchlist-detail-routing.module */ 2699);
/* harmony import */ var _components_watchlist_items_detail_watchlist_items_detail_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/watchlist-items-detail/watchlist-items-detail-routing.module */ 3117);
/* harmony import */ var _components_watchlist_queue_detail_watchlist_queue_detail_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/watchlist-queue-detail/watchlist-queue-detail-routing.module */ 4971);










let TabsPageModule = class TabsPageModule {
};
TabsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule,
            _tabs_routing_module__WEBPACK_IMPORTED_MODULE_0__.TabsPageRoutingModule,
            _components_watchlist_detail_watchlist_detail_routing_module__WEBPACK_IMPORTED_MODULE_2__.WatchListDetailPageRoutingModule,
            _components_watchlist_items_detail_watchlist_items_detail_routing_module__WEBPACK_IMPORTED_MODULE_3__.WatchListItemsDetailPageRoutingModule,
            _components_watchlist_queue_detail_watchlist_queue_detail_routing_module__WEBPACK_IMPORTED_MODULE_4__.WatchListQueueDetailPageRoutingModule
        ],
        declarations: [_tabs_page__WEBPACK_IMPORTED_MODULE_1__.TabsComponent]
    })
], TabsPageModule);



/***/ }),

/***/ 7942:
/*!***********************************!*\
  !*** ./src/app/tabs/tabs.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TabsComponent": () => (/* binding */ TabsComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _tabs_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tabs.page.html?ngResource */ 5230);
/* harmony import */ var _tabs_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tabs.page.scss?ngResource */ 4710);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _core_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../core/data.service */ 3943);





let TabsComponent = class TabsComponent {
    constructor(dataService) {
        this.dataService = dataService;
    }
};
TabsComponent.ctorParameters = () => [
    { type: _core_data_service__WEBPACK_IMPORTED_MODULE_2__.DataService }
];
TabsComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-tabs',
        template: _tabs_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_tabs_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], TabsComponent);



/***/ }),

/***/ 4710:
/*!************************************************!*\
  !*** ./src/app/tabs/tabs.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0YWJzLnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 5230:
/*!************************************************!*\
  !*** ./src/app/tabs/tabs.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<ion-tabs>\r\n     <ion-tab-bar *ngIf=\"!dataService.isError\" slot=\"bottom\">\r\n          <!--<ion-tab-button tab=\"login\" *ngIf=\"!dataService.isLoggedIn\">\r\n               <ion-label>Login</ion-label>\r\n          </ion-tab-button>-->\r\n\r\n          <ion-tab-button tab=\"watchlist\" *ngIf=\"dataService.isLoggedIn\">\r\n               <!-- <ion-icon name=\"triangle\"></ion-icon> -->\r\n               <ion-label>Watchlist</ion-label>\r\n          </ion-tab-button>\r\n\r\n          <ion-tab-button tab=\"watchlist-items\" *ngIf=\"dataService.isLoggedIn\">\r\n               <!-- <ion-icon name=\"ellipse\"></ion-icon> -->\r\n               <ion-label>Watchlist Items</ion-label>\r\n          </ion-tab-button>\r\n\r\n          <ion-tab-button tab=\"watchlist-queue\" *ngIf=\"dataService.isLoggedIn\">\r\n               <!-- <ion-icon name=\"ellipse\"></ion-icon> -->\r\n               <ion-label>Watchlist Queue</ion-label>\r\n          </ion-tab-button>\r\n\r\n          <ion-tab-button tab=\"imdb-search\" *ngIf=\"dataService.isIMDBSearchEnabled && dataService.isLoggedIn\">\r\n               <!-- <ion-icon name=\"ellipse\"></ion-icon> -->\r\n               <ion-label>IMDB Search</ion-label>\r\n          </ion-tab-button>\r\n\r\n          <ion-tab-button tab=\"watchlist-stats\" *ngIf=\"dataService.isLoggedIn\">\r\n               <!-- <ion-icon name=\"ellipse\"></ion-icon> -->\r\n               <ion-label>Watchlist Stats</ion-label>\r\n          </ion-tab-button>\r\n       </ion-tab-bar>\r\n</ion-tabs>\r\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tabs_tabs_module_ts.js.map