"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_components_imdb-search_imdb-search_module_ts"],{

/***/ 6811:
/*!**********************************************************************!*\
  !*** ./src/app/components/imdb-search/imdb-search-routing.module.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IMDBSearchPageRoutingModule": () => (/* binding */ IMDBSearchPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _imdb_search_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./imdb-search.page */ 3822);




const routes = [
    {
        path: '',
        component: _imdb_search_page__WEBPACK_IMPORTED_MODULE_0__.IMDBSearchComponent,
    }
];
let IMDBSearchPageRoutingModule = class IMDBSearchPageRoutingModule {
};
IMDBSearchPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], IMDBSearchPageRoutingModule);



/***/ }),

/***/ 8085:
/*!**************************************************************!*\
  !*** ./src/app/components/imdb-search/imdb-search.module.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IMDBSearchPageModule": () => (/* binding */ IMDBSearchPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _imdb_search_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./imdb-search.page */ 3822);
/* harmony import */ var _imdb_search_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./imdb-search-routing.module */ 6811);







let IMDBSearchPageModule = class IMDBSearchPageModule {
};
IMDBSearchPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _imdb_search_routing_module__WEBPACK_IMPORTED_MODULE_1__.IMDBSearchPageRoutingModule
        ],
        declarations: [_imdb_search_page__WEBPACK_IMPORTED_MODULE_0__.IMDBSearchComponent]
    })
], IMDBSearchPageModule);



/***/ }),

/***/ 3822:
/*!************************************************************!*\
  !*** ./src/app/components/imdb-search/imdb-search.page.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IMDBSearchComponent": () => (/* binding */ IMDBSearchComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _imdb_search_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./imdb-search.page.html?ngResource */ 9690);
/* harmony import */ var _imdb_search_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./imdb-search.page.scss?ngResource */ 452);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _core_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../core/data.service */ 3943);





let IMDBSearchComponent = class IMDBSearchComponent {
    constructor(dataService) {
        this.dataService = dataService;
        this.searchTerm = '';
    }
    ionViewDidEnter() {
        setTimeout(() => {
            this.search.setFocus();
        });
    }
    addSearchResult(currSearchResult, index) {
        const currWatchListItem = [];
        currWatchListItem.WatchListItemName = currSearchResult['Title'];
        if (currSearchResult['Type'] === 'movie') {
            currWatchListItem.WatchListTypeID = 1;
        }
        else if (currSearchResult['Type'] === 'series') {
            currWatchListItem.WatchListTypeID = 2;
        }
        else {
            currWatchListItem.WatchListTypeID = 3; // Other
        }
        currWatchListItem.IMDB_URL = `https://www.imdb.com/title/${currSearchResult['imdbID']}/`;
        currWatchListItem.IMDB_Poster = currSearchResult['Poster'];
        this.dataService.addWatchListItem(currWatchListItem).subscribe((response) => {
            if (response == null) { // No response on success
                this.searchResults.splice(index, 1); // Remove it from the the search results since its been added
                this.dataService.getWatchListItemsSubscription(true); // Reload WatchListItems after adding a WatchList record
                // When adding item through IMDB search, it may exist already. In this case, it won't have a new ID
                this.dataService.autoAddWatchListRecord(currWatchListItem.IMDB_URL);
            }
            else {
                this.dataService.alert('An error occurred adding the item');
            }
        }, error => {
            this.dataService.handleError(error);
        });
    }
    handleKeyUp(e) {
        if (e.keyCode === 13) { // Submit when enter is pressed
            this.searchIMDB();
        }
    }
    searchIMDB() {
        if (this.searchTerm !== '' && this.searchTerm !== null) {
            this.dataService.searchIMDB(this.searchTerm).subscribe((response) => {
                if (response.Response === 'False') {
                    this.dataService.alert(`${response.Error}`);
                }
                else {
                    this.searchTerm = '';
                    this.searchResults = Object.entries(response)[0][1]; // This contains the actual search results
                }
            }, error => {
                console.log(`An error occurred searching IMDB`);
                this.searchTerm = '';
            });
        }
        else {
            this.dataService.alert('Please enter a search term');
        }
    }
};
IMDBSearchComponent.ctorParameters = () => [
    { type: _core_data_service__WEBPACK_IMPORTED_MODULE_2__.DataService }
];
IMDBSearchComponent.propDecorators = {
    search: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.ViewChild, args: ['search',] }]
};
IMDBSearchComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-imdbsearch',
        template: _imdb_search_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_imdb_search_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], IMDBSearchComponent);



/***/ }),

/***/ 452:
/*!*************************************************************************!*\
  !*** ./src/app/components/imdb-search/imdb-search.page.scss?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = ".ion-list-parent {\n  width: 100%;\n  overflow: auto;\n}\n\nion-col {\n  vertical-align: top;\n}\n\nion-col.header {\n  padding-top: 20px;\n}\n\nion-content {\n  overflow: auto;\n}\n\nion-icon {\n  width: 35px;\n  height: 35px;\n}\n\nion-img {\n  width: 200px;\n  height: 200px;\n}\n\nion-input {\n  border-style: dashed;\n  border-width: 1px;\n}\n\nion-label {\n  font-size: 28px;\n}\n\nion-label.labelMobile {\n  font-size: 18px;\n}\n\nion-list.md.list-md {\n  min-width: 1000px;\n  overflow: auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImltZGItc2VhcmNoLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNJLFdBQUE7RUFDQSxjQUFBO0FBQUo7O0FBR0E7RUFDSSxtQkFBQTtBQUFKOztBQUdBO0VBQ0ksaUJBQUE7QUFBSjs7QUFHQTtFQUNJLGNBQUE7QUFBSjs7QUFHQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0FBQUo7O0FBR0E7RUFDSSxZQUFBO0VBQ0EsYUFBQTtBQUFKOztBQUdBO0VBQ0ksb0JBQUE7RUFDQSxpQkFBQTtBQUFKOztBQUdBO0VBQ0ksZUFBQTtBQUFKOztBQUdBO0VBQ0ksZUFBQTtBQUFKOztBQUdBO0VBQ0ksaUJBQUE7RUFDQSxjQUFBO0FBQUoiLCJmaWxlIjoiaW1kYi1zZWFyY2gucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbi5pb24tbGlzdC1wYXJlbnQge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBvdmVyZmxvdzogYXV0bztcclxufVxyXG5cclxuaW9uLWNvbCB7XHJcbiAgICB2ZXJ0aWNhbC1hbGlnbjogdG9wO1xyXG59XHJcblxyXG5pb24tY29sLmhlYWRlciB7XHJcbiAgICBwYWRkaW5nLXRvcDogMjBweDtcclxufVxyXG5cclxuaW9uLWNvbnRlbnQge1xyXG4gICAgb3ZlcmZsb3c6IGF1dG87XHJcbn1cclxuXHJcbmlvbi1pY29uIHtcclxuICAgIHdpZHRoOiAzNXB4O1xyXG4gICAgaGVpZ2h0OiAzNXB4O1xyXG59XHJcblxyXG5pb24taW1nIHtcclxuICAgIHdpZHRoOiAyMDBweDtcclxuICAgIGhlaWdodDogMjAwcHg7XHJcbn1cclxuXHJcbmlvbi1pbnB1dCB7XHJcbiAgICBib3JkZXItc3R5bGU6IGRhc2hlZDtcclxuICAgIGJvcmRlci13aWR0aDogMXB4O1xyXG59XHJcblxyXG5pb24tbGFiZWwge1xyXG4gICAgZm9udC1zaXplOiAyOHB4O1xyXG59XHJcblxyXG5pb24tbGFiZWwubGFiZWxNb2JpbGUge1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG59XHJcblxyXG5pb24tbGlzdC5tZC5saXN0LW1kIHtcclxuICAgIG1pbi13aWR0aDogMTAwMHB4O1xyXG4gICAgb3ZlcmZsb3c6IGF1dG87XHJcbn0iXX0= */";

/***/ }),

/***/ 9690:
/*!*************************************************************************!*\
  !*** ./src/app/components/imdb-search/imdb-search.page.html?ngResource ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header [translucent]=\"true\">\r\n    <ion-toolbar>\r\n         <ion-buttons slot=\"start\"> \r\n              <ion-menu-button></ion-menu-button>                \r\n         </ion-buttons>            \r\n         <ion-title>IMDB Search</ion-title>\r\n    </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content *ngIf=\"dataService.isBackendURLSet()\">\r\n    <ion-grid>\r\n        <ion-row>\r\n             <ion-col size=\"10\">\r\n               <ion-searchbar id=\"search\" #search (keyup)=\"handleKeyUp($event)\" [(ngModel)]=\"searchTerm\" show-cancel-button=\"never\"></ion-searchbar>\r\n          </ion-col>\r\n\r\n             <!--<ion-col class=\"header\" size=\"2\">\r\n                <ion-icon name=\"search-outline\" (click)=\"searchIMDB()\"></ion-icon>\r\n             </ion-col>-->\r\n        </ion-row>\r\n   </ion-grid>\r\n\r\n   <div class=\"ion-list-parent\">\r\n      <ion-list>\r\n         <ion-item *ngFor=\"let currSearchResult of searchResults;let index=index;\"> <!-- Table headers -->\r\n            <ion-grid>\r\n                 <ion-row>\r\n                      <ion-col size=\"12\">                        \r\n                        <ion-label><ion-icon name=\"add-outline\" (click)=\"addSearchResult(currSearchResult,index)\"></ion-icon> {{ currSearchResult['Title'] }} ( {{ currSearchResult['Year'] }} )</ion-label> \r\n                      </ion-col>\r\n\r\n                      <ion-col size=\"3\">\r\n                        <ion-img [src]=\"currSearchResult.Poster\"></ion-img>\r\n                      </ion-col>\r\n\r\n                      <ion-col size=\"6\"></ion-col>\r\n                 </ion-row>\r\n            </ion-grid>\r\n         </ion-item>\r\n      </ion-list>\r\n   </div>\r\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_components_imdb-search_imdb-search_module_ts.js.map